package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.model.ParsedPacket
import com.example.model.ProtocolType
import com.example.model.ThreatLevel
import com.example.ui.components.PacketListItem
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

    @get:Rule val composeTestRule = createComposeRule()

    @Test
    fun greeting_screenshot() {
        val testPacket = ParsedPacket(
            packetNumber = 1,
            timestampMs = System.currentTimeMillis(),
            sourceIp = "192.168.1.45",
            destinationIp = "142.250.190.46",
            sourcePort = 54321,
            destinationPort = 443,
            protocol = ProtocolType.TLS,
            totalLength = 512,
            info = "TLSv1.3 Client Hello (SNI: secure.bank.com)",
            isSuspicious = false,
            threatLevel = ThreatLevel.NONE,
            threatTitle = "",
            threatReason = "",
            threatMitigation = "",
            payloadHex = "16 03 01 02 00 01 00",
            payloadAscii = "......."
        )

        composeTestRule.setContent {
            MyApplicationTheme {
                PacketListItem(
                    packet = testPacket,
                    onClick = {}
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
    }
}
