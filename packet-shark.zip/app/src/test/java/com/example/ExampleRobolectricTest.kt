package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.analysis.ThreatDetector
import com.example.generator.TrafficSimulationEngine
import com.example.model.ProtocolType
import com.example.model.ThreatLevel
import com.example.parser.PacketParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Packet Shark", appName)
    }

    @Test
    fun `test packet parser handles dns packet`() {
        val normalPackets = TrafficSimulationEngine.generateScenarioPackets(
            TrafficSimulationEngine.Scenario.NORMAL_WEB,
            1
        )
        assertTrue(normalPackets.isNotEmpty())
        val parsed = PacketParser.parse(normalPackets[0], 1)
        assertNotNull(parsed)
        assertEquals(ProtocolType.DNS, parsed?.protocol)
        assertTrue(parsed?.dnsQueryDomain?.isNotEmpty() == true)
    }

    @Test
    fun `test threat detector catches credential exposure`() {
        val leakPackets = TrafficSimulationEngine.generateScenarioPackets(
            TrafficSimulationEngine.Scenario.PASSWORD_LEAK,
            5
        )
        assertTrue(leakPackets.isNotEmpty())
        val parsed = PacketParser.parse(leakPackets[0], 5)
        assertNotNull(parsed)

        val detector = ThreatDetector()
        val (analyzed, alert) = detector.analyze(parsed!!)
        assertTrue(analyzed.isSuspicious)
        assertEquals(ThreatLevel.HIGH, analyzed.threatLevel)
        assertNotNull(alert)
        assertEquals("Plaintext Credential Exposure", alert?.threatType)
    }
}
