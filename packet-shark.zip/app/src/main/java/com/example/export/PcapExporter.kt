package com.example.export

import android.content.Context
import com.example.model.ParsedPacket
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object PcapExporter {

    /**
     * Generates a standard Libpcap binary file format (.pcap) compatible with Wireshark.
     * LinkType: 101 (LINKTYPE_RAW - Raw IPv4/IPv6).
     */
    fun exportToPcapBytes(packets: List<ParsedPacket>): ByteArray {
        val out = ByteArrayOutputStream()

        // 24-byte PCAP Global Header
        val globalHeader = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        globalHeader.putInt(0xa1b2c3d4.toInt()) // Magic Number
        globalHeader.putShort(2)                 // Major Version
        globalHeader.putShort(4)                 // Minor Version
        globalHeader.putInt(0)                   // GMT to local correction
        globalHeader.putInt(0)                   // Accuracy of timestamps
        globalHeader.putInt(65535)               // Max length of captured packets (snaplen)
        globalHeader.putInt(101)                 // Data link type: LINKTYPE_RAW (raw IP)
        out.write(globalHeader.array())

        // Packet records
        val pktHeader = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN)
        for (pkt in packets) {
            val bytes = pkt.rawBytes
            if (bytes.isEmpty()) continue

            val tsSec = (pkt.timestampMs / 1000).toInt()
            val tsUsec = ((pkt.timestampMs % 1000) * 1000).toInt()
            val len = bytes.size

            pktHeader.clear()
            pktHeader.putInt(tsSec)
            pktHeader.putInt(tsUsec)
            pktHeader.putInt(len)                  // Saved packet length
            pktHeader.putInt(pkt.totalLength)      // Original packet length
            out.write(pktHeader.array())
            out.write(bytes)
        }

        return out.toByteArray()
    }

    fun savePcapToFile(context: Context, packets: List<ParsedPacket>): File {
        val fileName = "packet_shark_capture_${System.currentTimeMillis()}.pcap"
        val file = File(context.cacheDir, fileName)
        val data = exportToPcapBytes(packets)
        FileOutputStream(file).use { fos ->
            fos.write(data)
        }
        return file
    }
}
