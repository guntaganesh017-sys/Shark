package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.generator.TrafficSimulationEngine
import com.example.model.ParsedPacket
import com.example.model.ProtocolType
import com.example.model.ThreatAlert
import com.example.repository.CaptureStats
import com.example.repository.PacketRepository
import com.example.service.PacketCaptureVpnService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class PacketMonitorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PacketRepository.getInstance(application)

    val isCapturing: StateFlow<Boolean> = repository.isCapturing
    val isSimulating: StateFlow<Boolean> = repository.isSimulating
    val stats: StateFlow<CaptureStats> = repository.stats
    val threatAlerts: StateFlow<List<ThreatAlert>> = repository.threatAlerts

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedProtocolFilter = MutableStateFlow<ProtocolType?>(null)
    val selectedProtocolFilter: StateFlow<ProtocolType?> = _selectedProtocolFilter.asStateFlow()

    private val _onlySuspicious = MutableStateFlow(false)
    val onlySuspicious: StateFlow<Boolean> = _onlySuspicious.asStateFlow()

    private val _selectedPacket = MutableStateFlow<ParsedPacket?>(null)
    val selectedPacket: StateFlow<ParsedPacket?> = _selectedPacket.asStateFlow()

    private val _autoScroll = MutableStateFlow(true)
    val autoScroll: StateFlow<Boolean> = _autoScroll.asStateFlow()

    private val _showScenarioDialog = MutableStateFlow(false)
    val showScenarioDialog: StateFlow<Boolean> = _showScenarioDialog.asStateFlow()

    val filteredPackets: StateFlow<List<ParsedPacket>> = combine(
        repository.packets,
        _searchQuery,
        _selectedProtocolFilter,
        _onlySuspicious
    ) { all, query, protoFilter, suspiciousOnly ->
        all.filter { packet ->
            if (suspiciousOnly && !packet.isSuspicious) return@filter false
            if (protoFilter != null && packet.protocol != protoFilter) return@filter false
            if (query.isNotBlank()) {
                val q = query.trim().lowercase()
                val matchesIp = packet.sourceIp.contains(q) || packet.destinationIp.contains(q)
                val matchesPort = packet.sourcePort.toString().contains(q) || packet.destinationPort.toString().contains(q)
                val matchesInfo = packet.info.lowercase().contains(q)
                val matchesProto = packet.protocol.displayName.lowercase().contains(q)
                val matchesDns = packet.dnsQueryDomain?.lowercase()?.contains(q) == true
                val matchesThreat = packet.threatTitle.lowercase().contains(q)
                matchesIp || matchesPort || matchesInfo || matchesProto || matchesDns || matchesThreat
            } else {
                true
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onStartCaptureClick(context: Context, onRequestVpnPermission: (Intent) -> Unit) {
        val vpnIntent = VpnService.prepare(context)
        if (vpnIntent != null) {
            onRequestVpnPermission(vpnIntent)
        } else {
            startVpnService(context)
        }
    }

    fun startVpnService(context: Context) {
        val intent = Intent(context, PacketCaptureVpnService::class.java).apply {
            action = PacketCaptureVpnService.ACTION_START
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        repository.setCapturing(true)
    }

    fun stopCapture(context: Context) {
        val intent = Intent(context, PacketCaptureVpnService::class.java).apply {
            action = PacketCaptureVpnService.ACTION_STOP
        }
        context.startService(intent)
        repository.setCapturing(false)
        repository.stopContinuousSimulation()
    }

    fun toggleSimulation() {
        repository.toggleContinuousSimulation()
    }

    fun injectScenario(scenario: TrafficSimulationEngine.Scenario) {
        repository.injectScenario(scenario)
    }

    fun clearPackets() {
        repository.clearAll()
        _selectedPacket.value = null
    }

    fun exportPcap(onReady: (File) -> Unit) {
        viewModelScope.launch {
            val file = repository.exportPcap()
            onReady(file)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setProtocolFilter(protocol: ProtocolType?) {
        _selectedProtocolFilter.value = protocol
    }

    fun toggleOnlySuspicious() {
        _onlySuspicious.value = !_onlySuspicious.value
    }

    fun selectPacket(packet: ParsedPacket?) {
        _selectedPacket.value = packet
    }

    fun toggleAutoScroll() {
        _autoScroll.value = !_autoScroll.value
    }

    fun setShowScenarioDialog(show: Boolean) {
        _showScenarioDialog.value = show
    }
}
