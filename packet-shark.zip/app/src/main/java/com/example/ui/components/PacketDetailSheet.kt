package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ParsedPacket
import com.example.model.ProtocolType
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberError
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.getThreatColor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PacketDetailSheet(
    packet: ParsedPacket,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CyberSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProtocolBadge(protocol = packet.protocol)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Packet #${packet.packetNumber}",
                        color = CyberTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_packet_details_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = CyberTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Suspicious Threat Banner
            if (packet.isSuspicious) {
                ThreatBanner(packet = packet)
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Layer Dissectors (Wireshark-like Collapsible Tree)
            DissectSection(
                title = "Frame Layer (${packet.totalLength} bytes on wire)",
                defaultExpanded = false
            ) {
                DissectField("Packet Number", "#${packet.packetNumber}")
                DissectField("Capture Time", SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(packet.timestampMs)))
                DissectField("Frame Length", "${packet.totalLength} bytes (${packet.totalLength * 8} bits)")
                DissectField("Protocol", packet.protocol.displayName)
            }

            Spacer(modifier = Modifier.height(8.dp))

            DissectSection(
                title = "Internet Protocol Version ${packet.ipVersion} (${packet.sourceIp} → ${packet.destinationIp})",
                defaultExpanded = true
            ) {
                DissectField("IP Version", packet.ipVersion.toString())
                DissectField("Header Length (IHL)", "${packet.ipHeaderLength} bytes")
                DissectField("Time to Live (TTL)", packet.ttl.toString())
                DissectField("Flags", packet.flags.ifEmpty { "None (0x0000)" })
                DissectField("Source Address", packet.sourceIp)
                DissectField("Destination Address", packet.destinationIp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Transport Layer
            val transportTitle = when (packet.protocol) {
                ProtocolType.TCP -> "Transmission Control Protocol (Src Port: ${packet.sourcePort}, Dst Port: ${packet.destinationPort})"
                ProtocolType.UDP, ProtocolType.DNS -> "User Datagram Protocol (Src Port: ${packet.sourcePort}, Dst Port: ${packet.destinationPort})"
                ProtocolType.ICMP -> "Internet Control Message Protocol"
                else -> "Transport Layer"
            }

            DissectSection(
                title = transportTitle,
                defaultExpanded = true
            ) {
                if (packet.sourcePort > 0) DissectField("Source Port", packet.sourcePort.toString())
                if (packet.destinationPort > 0) DissectField("Destination Port", packet.destinationPort.toString())

                if (packet.protocol == ProtocolType.TCP || packet.protocol == ProtocolType.HTTP || packet.protocol == ProtocolType.TLS) {
                    DissectField("Sequence Number", packet.tcpSeq.toString())
                    DissectField("Acknowledgment Number", packet.tcpAck.toString())
                    DissectField("TCP Flags", packet.tcpFlags.ifEmpty { "ACK" })
                    DissectField("Window Size", "${packet.windowSize} bytes")
                }
            }

            // Application Layer (if applicable)
            if (packet.dnsQueryDomain != null || packet.httpMethod != null || packet.tlsSni != null) {
                Spacer(modifier = Modifier.height(8.dp))
                val appTitle = when {
                    packet.dnsQueryDomain != null -> "Domain Name System (Query: ${packet.dnsQueryDomain})"
                    packet.httpMethod != null -> "Hypertext Transfer Protocol (HTTP/${packet.httpMethod})"
                    packet.tlsSni != null -> "Transport Layer Security (SNI: ${packet.tlsSni})"
                    else -> "Application Protocol"
                }

                DissectSection(title = appTitle, defaultExpanded = true) {
                    packet.dnsQueryDomain?.let { DissectField("DNS Query Domain", it) }
                    packet.dnsQueryType?.let { DissectField("DNS Query Type", it) }
                    packet.httpMethod?.let { DissectField("HTTP Method", it) }
                    packet.httpPath?.let { DissectField("Request URI", it) }
                    packet.httpHost?.let { DissectField("Host Header", it) }
                    packet.tlsSni?.let { DissectField("TLS Server Name (SNI)", it) }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hex Dump
            HexDumpViewer(
                hexDump = packet.payloadHex,
                asciiDump = packet.payloadAscii
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ThreatBanner(packet: ParsedPacket) {
    val color = getThreatColor(packet.threatLevel)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${packet.threatLevel.label.uppercase()} THREAT DETECTED: ${packet.threatTitle}",
                    color = color,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (packet.threatReason.isNotEmpty()) {
                Text(
                    text = packet.threatReason,
                    color = CyberTextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }

            if (packet.threatMitigation.isNotEmpty()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Recommended Remediation: ${packet.threatMitigation}",
                    color = CyberAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun DissectSection(
    title: String,
    defaultExpanded: Boolean = true,
    content: @Composable () -> Unit
) {
    var expanded by remember { mutableStateOf(defaultExpanded) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceElevated)
            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = CyberAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = CyberTextSecondary
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun DissectField(name: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = name,
            color = CyberTextMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = CyberTextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace
        )
    }
}
