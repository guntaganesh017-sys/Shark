package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ProtocolType
import com.example.ui.components.PacketListItem
import com.example.ui.components.TrafficStatsHeader
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderSubtle
import com.example.ui.theme.CyberError
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSuccess
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarning
import com.example.ui.viewmodel.PacketMonitorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LivePacketsScreen(
    viewModel: PacketMonitorViewModel,
    onNavigateToThreats: () -> Unit,
    modifier: Modifier = Modifier
) {
    val packets by viewModel.filteredPackets.collectAsStateWithLifecycle()
    val isCapturing by viewModel.isCapturing.collectAsStateWithLifecycle()
    val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedProto by viewModel.selectedProtocolFilter.collectAsStateWithLifecycle()
    val onlySuspicious by viewModel.onlySuspicious.collectAsStateWithLifecycle()
    val autoScroll by viewModel.autoScroll.collectAsStateWithLifecycle()

    val listState = rememberLazyListState()

    // Auto-scroll to latest packet when enabled
    LaunchedEffect(packets.size, autoScroll) {
        if (autoScroll && packets.isNotEmpty()) {
            listState.animateScrollToItem(0)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(6.dp))

        // Traffic Stats Summary Banner
        TrafficStatsHeader(
            isCapturing = isCapturing,
            stats = stats,
            onThreatClick = onNavigateToThreats
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Internet Safety Status Banner (ensures YouTube, X, Grok, etc. remain online)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(CyberSurface)
                .border(1.dp, CyberBorderSubtle, RoundedCornerShape(8.dp))
                .clickable { viewModel.setShowRoutingDialog(true) }
                .padding(horizontal = 10.dp, vertical = 7.dp)
                .testTag("internet_protection_banner"),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(CyberSuccess.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = CyberSuccess,
                        modifier = Modifier.size(13.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Internet Protected: YouTube, X & Grok unblocked",
                    color = CyberTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(CyberSurfaceElevated)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Routing",
                    tint = CyberAccent,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "Routing",
                    color = CyberAccent,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Filter & Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = {
                Text(
                    text = "Filter IP, port (e.g. 443, 80), domain, protocol...",
                    color = CyberTextMuted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = CyberAccent,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear search",
                            tint = CyberTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CyberSurfaceElevated,
                unfocusedContainerColor = CyberSurface,
                focusedBorderColor = CyberAccent,
                unfocusedBorderColor = CyberBorder,
                focusedTextColor = CyberTextPrimary,
                unfocusedTextColor = CyberTextPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("packet_search_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Filter Chips Row (Scrollable)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Suspicious Only Chip
            FilterChip(
                selected = onlySuspicious,
                onClick = { viewModel.toggleOnlySuspicious() },
                label = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (onlySuspicious) CyberError else CyberTextMuted,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Threats Only", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyberError.copy(alpha = 0.2f),
                    selectedLabelColor = CyberError
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = onlySuspicious,
                    selectedBorderColor = CyberError,
                    borderColor = CyberBorder
                ),
                modifier = Modifier.testTag("filter_chip_threats")
            )

            // "All" Protocol Chip
            FilterChip(
                selected = selectedProto == null && !onlySuspicious,
                onClick = {
                    viewModel.setProtocolFilter(null)
                    if (onlySuspicious) viewModel.toggleOnlySuspicious()
                },
                label = { Text("ALL", fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyberPrimary.copy(alpha = 0.2f),
                    selectedLabelColor = CyberPrimary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedProto == null && !onlySuspicious,
                    selectedBorderColor = CyberPrimary,
                    borderColor = CyberBorder
                ),
                modifier = Modifier.testTag("filter_chip_all")
            )

            // Individual Protocols
            listOf(ProtocolType.TCP, ProtocolType.UDP, ProtocolType.DNS, ProtocolType.HTTP, ProtocolType.TLS, ProtocolType.ICMP).forEach { proto ->
                FilterChip(
                    selected = selectedProto == proto,
                    onClick = {
                        viewModel.setProtocolFilter(if (selectedProto == proto) null else proto)
                    },
                    label = { Text(proto.displayName, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberAccent.copy(alpha = 0.2f),
                        selectedLabelColor = CyberAccent
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selectedProto == proto,
                        selectedBorderColor = CyberAccent,
                        borderColor = CyberBorder
                    ),
                    modifier = Modifier.testTag("filter_chip_${proto.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Action Toolbar: Auto-scroll indicator & packet count
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Showing ${packets.size} packets",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Auto-scroll toggle chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (autoScroll) CyberAccent.copy(alpha = 0.15f) else CyberSurfaceElevated)
                        .border(1.dp, if (autoScroll) CyberAccent else CyberBorderSubtle, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (autoScroll) "AUTO-SCROLL ON" else "AUTO-SCROLL OFF",
                        color = if (autoScroll) CyberAccent else CyberTextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.testTag("toggle_autoscroll_button")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Packet Stream List
        if (packets.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        tint = CyberTextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = if (searchQuery.isNotEmpty() || onlySuspicious || selectedProto != null)
                            "No packets match current filter"
                        else "No packets captured yet",
                        color = CyberTextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Tap 'Simulate Traffic' or 'Start Capture' to capture packets in real-time.",
                        color = CyberTextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(bottom = 80.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("packet_list")
            ) {
                items(
                    items = packets,
                    key = { it.packetNumber }
                ) { packet ->
                    PacketListItem(
                        packet = packet,
                        onClick = { viewModel.selectPacket(packet) }
                    )
                }
            }
        }
    }
}
