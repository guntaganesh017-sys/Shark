package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ThreatLevel
import com.example.ui.components.ThreatAlertCard
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberError
import com.example.ui.theme.CyberSuccess
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarning
import com.example.ui.viewmodel.PacketMonitorViewModel

@Composable
fun ThreatsScreen(
    viewModel: PacketMonitorViewModel,
    modifier: Modifier = Modifier
) {
    val alerts by viewModel.threatAlerts.collectAsStateWithLifecycle()
    val allPackets by viewModel.filteredPackets.collectAsStateWithLifecycle()

    val highCount = alerts.count { it.severity == ThreatLevel.HIGH }
    val medCount = alerts.count { it.severity == ThreatLevel.MEDIUM }
    val lowCount = alerts.count { it.severity == ThreatLevel.LOW }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Security Posture Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (alerts.isEmpty()) CyberSuccess.copy(alpha = 0.1f) else CyberError.copy(alpha = 0.12f))
                .border(
                    1.dp,
                    if (alerts.isEmpty()) CyberSuccess.copy(alpha = 0.4f) else CyberError.copy(alpha = 0.6f),
                    RoundedCornerShape(12.dp)
                )
                .padding(14.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (alerts.isEmpty()) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (alerts.isEmpty()) CyberSuccess else CyberError,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (alerts.isEmpty()) "NETWORK POSTURE SECURE" else "ANOMALIES & THREATS DETECTED",
                                color = if (alerts.isEmpty()) CyberSuccess else CyberError,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (alerts.isEmpty()) "No suspicious event signatures matching known heuristics."
                                       else "$highCount High, $medCount Medium, $lowCount Low threat alerts active.",
                                color = CyberTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Breakdown Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThreatStatPill(
                        label = "High Severity",
                        count = highCount,
                        accentColor = CyberError,
                        modifier = Modifier.weight(1f)
                    )
                    ThreatStatPill(
                        label = "Medium",
                        count = medCount,
                        accentColor = CyberWarning,
                        modifier = Modifier.weight(1f)
                    )
                    ThreatStatPill(
                        label = "Low",
                        count = lowCount,
                        accentColor = Color(0xFFEAB308),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Actions Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "THREAT LOGS (${alerts.size})",
                color = CyberAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Button(
                onClick = { viewModel.setShowScenarioDialog(true) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberWarning.copy(alpha = 0.2f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberWarning),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.testTag("simulate_attack_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = CyberWarning,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Test Attack Rules",
                    color = CyberWarning,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Alerts List
        if (alerts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = CyberSuccess,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "Clean Network Traffic",
                        color = CyberTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "No cleartext credential leaks, port sweeps, DNS tunneling, or unauthorized backdoor connections detected in current traffic stream.",
                        color = CyberTextMuted,
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = { viewModel.setShowScenarioDialog(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceElevated),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                    ) {
                        Text(text = "Simulate Attack Vectors to Test Heuristics", color = CyberAccent, fontSize = 12.sp)
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 80.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("threats_list")
            ) {
                items(
                    items = alerts,
                    key = { it.id }
                ) { alert ->
                    ThreatAlertCard(
                        alert = alert,
                        onInspectClick = {
                            // Find the corresponding packet in the repository and open details
                            val match = allPackets.find { it.packetNumber == alert.packetNumber }
                            if (match != null) {
                                viewModel.selectPacket(match)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ThreatStatPill(
    label: String,
    count: Int,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
            .padding(vertical = 6.dp, horizontal = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = count.toString(),
                color = if (count > 0) accentColor else CyberTextMuted,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = label,
                color = CyberTextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
