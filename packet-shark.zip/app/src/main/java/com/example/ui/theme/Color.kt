package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.model.ProtocolType
import com.example.model.ThreatLevel

// Cyber Dark Palette
val CyberBg = Color(0xFF080D1A)
val CyberSurface = Color(0xFF0F172A)
val CyberSurfaceElevated = Color(0xFF1E293B)
val CyberSurfaceHover = Color(0xFF27354E)
val CyberBorder = Color(0xFF334155)
val CyberBorderSubtle = Color(0xFF1E293B)

val CyberPrimary = Color(0xFF38BDF8) // Glowing Sky Cyan
val CyberPrimaryContainer = Color(0xFF075985)
val CyberOnPrimary = Color(0xFF002238)

val CyberSecondary = Color(0xFF818CF8) // Indigo
val CyberSecondaryContainer = Color(0xFF3730A3)
val CyberOnSecondary = Color(0xFF0F1035)

val CyberAccent = Color(0xFF06B6D4)
val CyberSuccess = Color(0xFF10B981)
val CyberWarning = Color(0xFFF59E0B)
val CyberError = Color(0xFFEF4444)

val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextMuted = Color(0xFF64748B)

fun getProtocolColor(protocol: ProtocolType): Color {
    return when (protocol) {
        ProtocolType.TCP -> Color(0xFF38BDF8)    // Cyan
        ProtocolType.UDP -> Color(0xFFA855F7)    // Violet
        ProtocolType.DNS -> Color(0xFFF59E0B)    // Amber
        ProtocolType.HTTP -> Color(0xFF10B981)   // Green
        ProtocolType.TLS -> Color(0xFF06B6D4)    // Teal
        ProtocolType.ICMP -> Color(0xFFF43F5E)   // Rose
        ProtocolType.OTHER -> Color(0xFF94A3B8)  // Gray
    }
}

fun getThreatColor(level: ThreatLevel): Color {
    return when (level) {
        ThreatLevel.HIGH -> Color(0xFFEF4444)
        ThreatLevel.MEDIUM -> Color(0xFFF97316)
        ThreatLevel.LOW -> Color(0xFFEAB308)
        ThreatLevel.NONE -> Color(0xFF10B981)
    }
}
