package com.example.repository

import android.content.Context
import com.example.analysis.ThreatDetector
import com.example.data.local.AppDatabase
import com.example.data.local.CapturedPacketEntity
import com.example.data.local.SecurityAlertEntity
import com.example.export.PcapExporter
import com.example.generator.TrafficSimulationEngine
import com.example.model.ParsedPacket
import com.example.model.ProtocolType
import com.example.model.ThreatAlert
import com.example.model.ThreatLevel
import com.example.parser.PacketParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicLong

data class CaptureStats(
    val totalPackets: Long = 0,
    val suspiciousCount: Long = 0,
    val totalBytes: Long = 0,
    val packetsPerSec: Int = 0,
    val bytesPerSec: Long = 0,
    val protocolCounts: Map<ProtocolType, Int> = emptyMap(),
    val topDestPorts: List<Pair<Int, Int>> = emptyList(),
    val topTalkerIps: List<Pair<String, Int>> = emptyList()
)

class PacketRepository private constructor(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val packetDao = db.packetDao()
    private val alertDao = db.alertDao()
    private val threatDetector = ThreatDetector()
    private val repoScope = CoroutineScope(Dispatchers.Default + Job())

    private val packetCounter = AtomicLong(1)
    private val _isCapturing = MutableStateFlow(false)
    val isCapturing: StateFlow<Boolean> = _isCapturing.asStateFlow()

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private val _packets = MutableStateFlow<List<ParsedPacket>>(emptyList())
    val packets: StateFlow<List<ParsedPacket>> = _packets.asStateFlow()

    private val _threatAlerts = MutableStateFlow<List<ThreatAlert>>(emptyList())
    val threatAlerts: StateFlow<List<ThreatAlert>> = _threatAlerts.asStateFlow()

    private val _stats = MutableStateFlow(CaptureStats())
    val stats: StateFlow<CaptureStats> = _stats.asStateFlow()

    private var simulationJob: Job? = null
    private var statsRateJob: Job? = null

    // Tracking for rate calculation
    private var lastSampleTime = System.currentTimeMillis()
    private var packetsSinceLastSample = 0
    private var bytesSinceLastSample = 0L

    init {
        // Load initial historical alerts and packets from DB in background
        repoScope.launch(Dispatchers.IO) {
            alertDao.getAllAlerts().collect { list ->
                if (_threatAlerts.value.isEmpty() && list.isNotEmpty()) {
                    _threatAlerts.value = list.map { it.toThreatAlert() }
                }
            }
        }
        startRateCalculator()
        // Auto-seed an initial realistic burst so the UI starts with live network activity immediately
        seedInitialTraffic()
    }

    private fun seedInitialTraffic() {
        repoScope.launch {
            val normalPackets = TrafficSimulationEngine.generateScenarioPackets(
                TrafficSimulationEngine.Scenario.NORMAL_WEB,
                packetCounter.get()
            )
            for (raw in normalPackets) {
                ingestRawPacket(raw)
            }
        }
    }

    private fun startRateCalculator() {
        statsRateJob?.cancel()
        statsRateJob = repoScope.launch {
            while (isActive) {
                delay(1000)
                val now = System.currentTimeMillis()
                val delta = (now - lastSampleTime).coerceAtLeast(1)
                val pps = ((packetsSinceLastSample * 1000L) / delta).toInt()
                val bps = (bytesSinceLastSample * 1000L) / delta

                packetsSinceLastSample = 0
                bytesSinceLastSample = 0L
                lastSampleTime = now

                _stats.update { current ->
                    current.copy(
                        packetsPerSec = if (_isCapturing.value || _isSimulating.value) pps else 0,
                        bytesPerSec = if (_isCapturing.value || _isSimulating.value) bps else 0
                    )
                }
            }
        }
    }

    fun setCapturing(active: Boolean) {
        _isCapturing.value = active
        if (active && !_isSimulating.value) {
            // Also enable background generator so emulator / device receives active packets
            startContinuousSimulation()
        }
    }

    fun toggleContinuousSimulation() {
        if (_isSimulating.value) {
            stopContinuousSimulation()
        } else {
            startContinuousSimulation()
        }
    }

    fun startContinuousSimulation() {
        if (_isSimulating.value) return
        _isSimulating.value = true
        _isCapturing.value = true

        simulationJob?.cancel()
        simulationJob = repoScope.launch {
            while (isActive && _isSimulating.value) {
                val raw = TrafficSimulationEngine.generateRandomPacket()
                ingestRawPacket(raw)
                delay((120..350).random().toLong())
            }
        }
    }

    fun stopContinuousSimulation() {
        _isSimulating.value = false
        simulationJob?.cancel()
        simulationJob = null
        if (!_isCapturing.value) {
            _stats.update { it.copy(packetsPerSec = 0, bytesPerSec = 0) }
        }
    }

    fun injectScenario(scenario: TrafficSimulationEngine.Scenario) {
        repoScope.launch {
            val packets = TrafficSimulationEngine.generateScenarioPackets(
                scenario,
                packetCounter.get()
            )
            for (raw in packets) {
                ingestRawPacket(raw)
                delay(60)
            }
        }
    }

    fun ingestRawPacket(rawBytes: ByteArray) {
        val pktNum = packetCounter.getAndIncrement()
        val parsed = PacketParser.parse(rawBytes, pktNum) ?: return
        val (analyzedPacket, alert) = threatDetector.analyze(parsed)

        packetsSinceLastSample++
        bytesSinceLastSample += analyzedPacket.totalLength

        // Update in-memory reactive list (ring buffer max 400 packets for optimal Compose performance)
        _packets.update { current ->
            val newList = ArrayList<ParsedPacket>(current.size + 1)
            newList.add(analyzedPacket)
            if (current.size >= 400) {
                newList.addAll(current.subList(0, 399))
            } else {
                newList.addAll(current)
            }
            newList
        }

        if (alert != null) {
            _threatAlerts.update { current ->
                listOf(alert) + current.take(199)
            }
            // Persist alert to Room
            repoScope.launch(Dispatchers.IO) {
                alertDao.insertAlert(SecurityAlertEntity.fromThreatAlert(alert))
            }
        }

        // Persist packet to Room asynchronously
        repoScope.launch(Dispatchers.IO) {
            packetDao.insertPacket(CapturedPacketEntity.fromParsedPacket(analyzedPacket))
        }

        // Update aggregate statistics
        updateStats(analyzedPacket)
    }

    private fun updateStats(packet: ParsedPacket) {
        _stats.update { current ->
            val newTotal = current.totalPackets + 1
            val newSuspicious = if (packet.isSuspicious) current.suspiciousCount + 1 else current.suspiciousCount
            val newBytes = current.totalBytes + packet.totalLength

            val protoMap = current.protocolCounts.toMutableMap()
            protoMap[packet.protocol] = (protoMap[packet.protocol] ?: 0) + 1

            // Top Talkers
            val talkerMap = current.topTalkerIps.toMap().toMutableMap()
            talkerMap[packet.sourceIp] = (talkerMap[packet.sourceIp] ?: 0) + 1
            val topTalkers = talkerMap.toList().sortedByDescending { it.second }.take(5)

            // Top Ports
            val portMap = current.topDestPorts.toMap().toMutableMap()
            if (packet.destinationPort > 0) {
                portMap[packet.destinationPort] = (portMap[packet.destinationPort] ?: 0) + 1
            }
            val topPorts = portMap.toList().sortedByDescending { it.second }.take(5)

            current.copy(
                totalPackets = newTotal,
                suspiciousCount = newSuspicious,
                totalBytes = newBytes,
                protocolCounts = protoMap,
                topTalkerIps = topTalkers,
                topDestPorts = topPorts
            )
        }
    }

    fun clearAll() {
        _packets.value = emptyList()
        _threatAlerts.value = emptyList()
        _stats.value = CaptureStats()
        repoScope.launch(Dispatchers.IO) {
            packetDao.clearAll()
            alertDao.clearAll()
        }
    }

    fun exportPcap(): File {
        return PcapExporter.savePcapToFile(context, _packets.value)
    }

    companion object {
        @Volatile
        private var INSTANCE: PacketRepository? = null

        fun getInstance(context: Context): PacketRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PacketRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
