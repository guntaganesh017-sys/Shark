package com.example.analysis

import com.example.model.ParsedPacket
import com.example.model.ProtocolType
import com.example.model.ThreatAlert
import com.example.model.ThreatLevel
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

class ThreatDetector {

    // Tracking state for port scan detection
    private val synHistory = ConcurrentHashMap<String, MutableList<Pair<Int, Long>>>()
    private val alertCounter = java.util.concurrent.atomic.AtomicLong(1)

    fun analyze(packet: ParsedPacket): Pair<ParsedPacket, ThreatAlert?> {
        val payloadStr = try {
            if (packet.rawBytes.isNotEmpty()) {
                String(packet.rawBytes, StandardCharsets.ISO_8859_1).lowercase()
            } else ""
        } catch (e: Exception) { "" }

        // 1. Check for Plaintext Password / Sensitive Credential Leak (HIGH)
        val credFinding = checkPlaintextCredentials(packet, payloadStr)
        if (credFinding != null) {
            val alert = ThreatAlert(
                id = alertCounter.getAndIncrement(),
                packetNumber = packet.packetNumber,
                timestampMs = packet.timestampMs,
                threatType = "Plaintext Credential Exposure",
                severity = ThreatLevel.HIGH,
                sourceEndpoint = "${packet.sourceIp}:${packet.sourcePort}",
                destEndpoint = "${packet.destinationIp}:${packet.destinationPort}",
                description = "Cleartext authentication data or secret token found in unencrypted transmission.",
                technicalEvidence = credFinding,
                remediation = "Enforce HTTPS/TLS encryption immediately. Never transmit authentication tokens or passwords across cleartext protocols."
            )
            val updated = packet.copy(
                isSuspicious = true,
                threatLevel = ThreatLevel.HIGH,
                threatTitle = "Plaintext Credential Leak",
                threatReason = "Sensitive credential keyword detected in cleartext payload: $credFinding",
                threatMitigation = "Enforce HTTPS/TLS encryption. Refrain from plain HTTP transmission."
            )
            return Pair(updated, alert)
        }

        // 2. Check for Known Malicious / Backdoor / High-Risk Port (HIGH)
        val maliciousPortFinding = checkKnownMaliciousPorts(packet.destinationPort, packet.sourcePort)
        if (maliciousPortFinding != null) {
            val alert = ThreatAlert(
                id = alertCounter.getAndIncrement(),
                packetNumber = packet.packetNumber,
                timestampMs = packet.timestampMs,
                threatType = maliciousPortFinding.type,
                severity = ThreatLevel.HIGH,
                sourceEndpoint = "${packet.sourceIp}:${packet.sourcePort}",
                destEndpoint = "${packet.destinationIp}:${packet.destinationPort}",
                description = maliciousPortFinding.description,
                technicalEvidence = "Connection to port ${packet.destinationPort} (Known threat: ${maliciousPortFinding.signature})",
                remediation = maliciousPortFinding.remediation
            )
            val updated = packet.copy(
                isSuspicious = true,
                threatLevel = ThreatLevel.HIGH,
                threatTitle = maliciousPortFinding.type,
                threatReason = maliciousPortFinding.description,
                threatMitigation = maliciousPortFinding.remediation
            )
            return Pair(updated, alert)
        }

        // 3. Check for DNS Tunneling & Data Exfiltration (HIGH)
        if (packet.protocol == ProtocolType.DNS && packet.dnsQueryDomain != null) {
            val domain = packet.dnsQueryDomain
            val dnsFinding = checkDnsTunneling(domain, packet.dnsQueryType)
            if (dnsFinding != null) {
                val alert = ThreatAlert(
                    id = alertCounter.getAndIncrement(),
                    packetNumber = packet.packetNumber,
                    timestampMs = packet.timestampMs,
                    threatType = "DNS Tunneling / Data Exfiltration",
                    severity = ThreatLevel.HIGH,
                    sourceEndpoint = "${packet.sourceIp}:${packet.sourcePort}",
                    destEndpoint = "${packet.destinationIp}:${packet.destinationPort}",
                    description = "Anomalously long or encoded DNS query label suggesting covert tunnel or data leak.",
                    technicalEvidence = dnsFinding,
                    remediation = "Enforce DNS inspection on internal firewalls and block dynamic covert tunnels. Quarantine offending application."
                )
                val updated = packet.copy(
                    isSuspicious = true,
                    threatLevel = ThreatLevel.HIGH,
                    threatTitle = "DNS Tunneling Exfiltration",
                    threatReason = dnsFinding,
                    threatMitigation = "Block dynamic DNS exfiltration domain and inspect host process."
                )
                return Pair(updated, alert)
            }

            // Suspicious TLD / C2 Domain Check
            val c2Finding = checkSuspiciousC2Domain(domain)
            if (c2Finding != null) {
                val alert = ThreatAlert(
                    id = alertCounter.getAndIncrement(),
                    packetNumber = packet.packetNumber,
                    timestampMs = packet.timestampMs,
                    threatType = "Suspicious C2 Domain Pattern",
                    severity = ThreatLevel.MEDIUM,
                    sourceEndpoint = "${packet.sourceIp}:${packet.sourcePort}",
                    destEndpoint = "${packet.destinationIp}:${packet.destinationPort}",
                    description = "DNS query to known suspicious high-abuse TLD or algorithmically generated domain pattern.",
                    technicalEvidence = "Domain: $domain ($c2Finding)",
                    remediation = "Check domain reputation with threat intelligence and restrict untrusted TLDs."
                )
                val updated = packet.copy(
                    isSuspicious = true,
                    threatLevel = ThreatLevel.MEDIUM,
                    threatTitle = "Suspicious C2 Domain",
                    threatReason = "High-abuse TLD or DGA pattern: $domain",
                    threatMitigation = "Verify domain reputation on Threat Intelligence feeds."
                )
                return Pair(updated, alert)
            }
        }

        // 4. Port Scan / Reconnaissance Detection (MEDIUM)
        if (packet.protocol == ProtocolType.TCP && packet.tcpFlags.contains("SYN") && !packet.tcpFlags.contains("ACK")) {
            val scanAlert = checkPortScan(packet)
            if (scanAlert != null) {
                val updated = packet.copy(
                    isSuspicious = true,
                    threatLevel = ThreatLevel.MEDIUM,
                    threatTitle = "TCP Port Scan Sweep",
                    threatReason = "Rapid TCP SYN connections across multiple port targets detected.",
                    threatMitigation = "Investigate source application initiating sequential port connections."
                )
                return Pair(updated, scanAlert)
            }
        }

        // 5. Insecure Cleartext Web Forms (LOW/MEDIUM)
        if (packet.protocol == ProtocolType.HTTP && (packet.httpMethod == "POST" || packet.httpMethod == "PUT")) {
            if (payloadStr.contains("cookie:") || payloadStr.contains("session") || payloadStr.contains("user")) {
                val alert = ThreatAlert(
                    id = alertCounter.getAndIncrement(),
                    packetNumber = packet.packetNumber,
                    timestampMs = packet.timestampMs,
                    threatType = "Insecure HTTP Form Transmission",
                    severity = ThreatLevel.LOW,
                    sourceEndpoint = "${packet.sourceIp}:${packet.sourcePort}",
                    destEndpoint = "${packet.destinationIp}:${packet.destinationPort}",
                    description = "Form data or session cookies sent via unencrypted HTTP (Port 80).",
                    technicalEvidence = "HTTP ${packet.httpMethod} ${packet.httpPath ?: ""} Host: ${packet.httpHost ?: ""}",
                    remediation = "Enable Strict-Transport-Security (HSTS) and require HTTPS for all API/form endpoints."
                )
                val updated = packet.copy(
                    isSuspicious = true,
                    threatLevel = ThreatLevel.LOW,
                    threatTitle = "Insecure HTTP Form Transmission",
                    threatReason = "Unencrypted HTTP POST transmitting sensitive request parameters.",
                    threatMitigation = "Transition to HTTPS to prevent man-in-the-middle packet eavesdropping."
                )
                return Pair(updated, alert)
            }
        }

        return Pair(packet, null)
    }

    private fun checkPlaintextCredentials(packet: ParsedPacket, payload: String): String? {
        if (payload.isEmpty()) return null
        // Skip TLS encrypted application data (starts with 0x17 or high entropy binary)
        if (packet.protocol == ProtocolType.TLS && packet.tlsSni == null) return null

        val sensitiveKeywords = listOf(
            "password=", "passwd=", "pwd=", "login_password=",
            "api_key=", "apikey=", "access_token=", "secret_key=",
            "authorization: basic", "bearer eyj", "private_key"
        )

        for (kw in sensitiveKeywords) {
            val idx = payload.indexOf(kw)
            if (idx != -1) {
                val snippetEnd = (idx + 40).coerceAtMost(payload.length)
                return payload.substring(idx, snippetEnd).replace("\r", " ").replace("\n", " ")
            }
        }
        return null
    }

    data class MaliciousPortInfo(val type: String, val signature: String, val description: String, val remediation: String)

    private fun checkKnownMaliciousPorts(dstPort: Int, srcPort: Int): MaliciousPortInfo? {
        val port = if (dstPort in 1..65535) dstPort else srcPort
        return when (port) {
            4444 -> MaliciousPortInfo(
                type = "Metasploit Reverse Shell Listener",
                signature = "Port 4444",
                description = "Port 4444 is default listener port for Metasploit/Meterpreter remote shells.",
                remediation = "Verify and terminate any unauthorized reverse-connection process immediately."
            )
            1337, 31337 -> MaliciousPortInfo(
                type = "Backdoor / Elite Trojan Port",
                signature = "Port $port",
                description = "Port $port is historically associated with remote access trojans (RATs) and backdoors.",
                remediation = "Isolate device network access and run malware scan on installed packages."
            )
            6667, 6666 -> MaliciousPortInfo(
                type = "IRC Botnet C2 Channel",
                signature = "Port $port",
                description = "Port $port (IRC) is commonly utilized by botnets for remote command and control broadcast.",
                remediation = "Inspect application communicating over IRC ports without legitimate user request."
            )
            23 -> MaliciousPortInfo(
                type = "Cleartext Telnet Port",
                signature = "Port 23",
                description = "Telnet protocol transmits all keystrokes and credentials completely unencrypted.",
                remediation = "Disable Telnet and use SSH (Port 22) for secure encrypted management."
            )
            5555 -> MaliciousPortInfo(
                type = "Exposed Android ADB Wireless Interface",
                signature = "Port 5555",
                description = "Port 5555 exposes Android Debug Bridge (ADB) over the local Wi-Fi, allowing full remote root/command execution.",
                remediation = "Disable ADB over network in Developer Settings immediately to prevent unauthorized device compromise."
            )
            21 -> MaliciousPortInfo(
                type = "Insecure FTP Port",
                signature = "Port 21",
                description = "Legacy File Transfer Protocol (FTP) sends usernames and passwords unencrypted.",
                remediation = "Migrate to SFTP (Port 22) or FTPS with enforced TLS encryption."
            )
            else -> null
        }
    }

    private fun checkDnsTunneling(domain: String, queryType: String?): String? {
        // Domain length > 45 or long base64/hex subdomain
        val parts = domain.split(".")
        if (parts.isNotEmpty()) {
            val sub = parts[0]
            if (sub.length > 35) {
                return "Subdomain label length (${sub.length} chars) exceeds normal threshold: $domain"
            }
            if (queryType == "TXT" && sub.length > 25) {
                return "DNS TXT record query with suspicious encoded payload: $domain"
            }
            // Check high entropy or hex/base64 pattern
            val isHexLike = sub.matches(Regex("^[0-9a-fA-F]{24,}$"))
            val isBase64Like = sub.matches(Regex("^[A-Za-z0-9+/=]{24,}$"))
            if (isHexLike || isBase64Like) {
                return "Encoded data payload detected in DNS query: $domain"
            }
        }
        return null
    }

    private fun checkSuspiciousC2Domain(domain: String): String? {
        val suspiciousTlds = listOf(".top", ".xyz", ".buzz", ".onion", ".cc", ".monster", ".work")
        for (tld in suspiciousTlds) {
            if (domain.endsWith(tld, ignoreCase = true)) {
                // Check if name has random alphanumeric string
                val name = domain.removeSuffix(tld).substringAfterLast(".")
                if (name.length > 10 && name.any { it.isDigit() } && name.any { it.isLetter() }) {
                    return "Potential DGA (Domain Generation Algorithm) name ending in $tld"
                }
            }
        }
        return null
    }

    private fun checkPortScan(packet: ParsedPacket): ThreatAlert? {
        val now = System.currentTimeMillis()
        val src = packet.sourceIp
        val list = synHistory.computeIfAbsent(src) { mutableListOf() }

        synchronized(list) {
            list.removeAll { now - it.second > 10_000 } // Keep last 10 seconds
            list.add(Pair(packet.destinationPort, now))

            val distinctPorts = list.map { it.first }.toSet()
            if (distinctPorts.size >= 5) {
                list.clear() // Alert triggered, reset counter for next window
                return ThreatAlert(
                    id = alertCounter.getAndIncrement(),
                    packetNumber = packet.packetNumber,
                    timestampMs = now,
                    threatType = "TCP Port Scan Sweep Detected",
                    severity = ThreatLevel.MEDIUM,
                    sourceEndpoint = "${packet.sourceIp}:${packet.sourcePort}",
                    destEndpoint = "${packet.destinationIp} (Multiple Ports)",
                    description = "Source host sent TCP SYN packets to ${distinctPorts.size} distinct ports within a 10s window.",
                    technicalEvidence = "Scanned Ports: ${distinctPorts.take(8).joinToString(", ")}...",
                    remediation = "Host exhibits network reconnaissance patterns. Inspect active sockets or restrict outbound scanning."
                )
            }
        }
        return null
    }
}
