package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.CaptureConfigManager
import com.example.model.CaptureMode
import com.example.repository.PacketRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger

class PacketCaptureVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var captureJob: Job? = null
    private var forwardSocket: DatagramSocket? = null
    private val packetIdCounter = AtomicInteger(1)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        if (vpnInterface != null) return

        try {
            val configManager = CaptureConfigManager.getInstance(this)
            val currentMode = configManager.currentMode.value
            val bypassedPackages = configManager.bypassedPackages.value
            val targetPackages = configManager.targetPackages.value

            val builder = Builder()
                .setSession("PacketSharkCapture")
                .setMtu(1500)
                .setBlocking(false)

            when (currentMode) {
                CaptureMode.SAFE_INTERNET -> {
                    // Non-disruptive Sentinel mode:
                    // Route virtual address and DNS so YouTube, X, Grok, etc. keep 100% full-speed internet
                    builder.addAddress("10.1.1.2", 32)
                    builder.addDnsServer("10.1.1.2")
                    builder.addRoute("10.1.1.2", 32)

                    // Also disallow known consumer apps so OS routes them natively without VPN overhead
                    val pm = packageManager
                    for (pkg in bypassedPackages) {
                        try {
                            pm.getPackageInfo(pkg, 0)
                            builder.addDisallowedApplication(pkg)
                        } catch (_: Exception) {}
                    }
                }
                CaptureMode.APP_BYPASS -> {
                    // Device wide capture, excluding specified apps (YouTube, X, Grok, etc.)
                    builder.addAddress("10.1.1.2", 32)
                    builder.addDnsServer("8.8.8.8")
                    builder.addRoute("0.0.0.0", 0)

                    val pm = packageManager
                    for (pkg in bypassedPackages) {
                        try {
                            pm.getPackageInfo(pkg, 0)
                            builder.addDisallowedApplication(pkg)
                        } catch (_: Exception) {}
                    }
                }
                CaptureMode.TARGET_APPS -> {
                    // Only inspect selected apps; all other apps (YouTube, X, Grok) bypass VPN automatically
                    builder.addAddress("10.1.1.2", 32)
                    builder.addDnsServer("8.8.8.8")
                    builder.addRoute("0.0.0.0", 0)

                    val pm = packageManager
                    val targets = if (targetPackages.isNotEmpty()) targetPackages else setOf(packageName)
                    for (pkg in targets) {
                        try {
                            pm.getPackageInfo(pkg, 0)
                            builder.addAllowedApplication(pkg)
                        } catch (_: Exception) {}
                    }
                }
            }

            vpnInterface = builder.establish()
            val repo = PacketRepository.getInstance(applicationContext)
            repo.setCapturing(true)

            val pfd = vpnInterface ?: return
            val inStream = FileInputStream(pfd.fileDescriptor)
            val outStream = FileOutputStream(pfd.fileDescriptor)

            // Protected UDP socket for forwarding DNS and UDP queries to real internet
            try {
                forwardSocket = DatagramSocket().apply {
                    protect(this)
                    soTimeout = 2500
                }
            } catch (_: Exception) {}

            captureJob?.cancel()
            captureJob = serviceScope.launch {
                val buffer = ByteBuffer.allocate(32768)
                val channel = inStream.channel

                while (isActive) {
                    buffer.clear()
                    val bytesRead = try {
                        channel.read(buffer)
                    } catch (e: Exception) {
                        -1
                    }

                    if (bytesRead > 0) {
                        buffer.flip()
                        val packetData = ByteArray(bytesRead)
                        buffer.get(packetData)
                        repo.ingestRawPacket(packetData)

                        // Forward UDP / DNS packets so querying apps get their network replies
                        handleUdpForwarding(packetData, outStream, repo)
                    } else {
                        // Short sleep to prevent busy spinning when non-blocking has no packets
                        Thread.sleep(15)
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback to simulation mode if device restricts local loopback VPN
            PacketRepository.getInstance(applicationContext).startContinuousSimulation()
        }
    }

    private fun handleUdpForwarding(
        packetData: ByteArray,
        outStream: FileOutputStream,
        repo: PacketRepository
    ) {
        if (packetData.size < 28) return
        val version = (packetData[0].toInt() shr 4) and 0x0F
        if (version != 4) return // Forward IPv4 UDP
        val ihl = (packetData[0].toInt() and 0x0F) * 4
        if (packetData.size < ihl + 8) return

        val protocol = packetData[9].toInt() and 0xFF
        if (protocol != 17) return // Protocol 17 = UDP

        val srcIpBytes = packetData.copyOfRange(12, 16)
        val dstIpBytes = packetData.copyOfRange(16, 20)

        val srcPort = ((packetData[ihl].toInt() and 0xFF) shl 8) or (packetData[ihl + 1].toInt() and 0xFF)
        val dstPort = ((packetData[ihl + 2].toInt() and 0xFF) shl 8) or (packetData[ihl + 3].toInt() and 0xFF)
        val udpLen = ((packetData[ihl + 4].toInt() and 0xFF) shl 8) or (packetData[ihl + 5].toInt() and 0xFF)

        val payloadOffset = ihl + 8
        val payloadLen = (udpLen - 8).coerceAtLeast(0)
        if (payloadOffset + payloadLen > packetData.size || payloadLen <= 0) return

        val udpPayload = packetData.copyOfRange(payloadOffset, payloadOffset + payloadLen)

        val socket = forwardSocket ?: return

        serviceScope.launch(Dispatchers.IO) {
            try {
                // If sent to local virtual TUN DNS 10.1.1.2 or standard DNS 53, send to Google DNS 8.8.8.8
                val destIp = InetAddress.getByAddress(dstIpBytes)
                val targetHost = if (destIp.hostAddress == "10.1.1.2" || dstPort == 53) {
                    InetAddress.getByName("8.8.8.8")
                } else {
                    destIp
                }

                val sendPacket = DatagramPacket(udpPayload, udpPayload.size, targetHost, dstPort)
                socket.send(sendPacket)

                val replyBuf = ByteArray(4096)
                val replyPacket = DatagramPacket(replyBuf, replyBuf.size)
                socket.receive(replyPacket)

                val replyLen = replyPacket.length
                val replyPayload = replyPacket.data.copyOf(replyLen)

                // Synthesize valid IPv4 + UDP reply packet to write back to TUN
                val responseRaw = buildIpv4UdpPacket(
                    srcIp = dstIpBytes,
                    dstIp = srcIpBytes,
                    srcPort = dstPort,
                    dstPort = srcPort,
                    payload = replyPayload
                )

                synchronized(outStream) {
                    outStream.write(responseRaw)
                }

                repo.ingestRawPacket(responseRaw)
            } catch (_: Exception) {
                // UDP timeout or network error, ignore
            }
        }
    }

    private fun buildIpv4UdpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val totalLength = 20 + 8 + payload.size
        val packet = ByteArray(totalLength)

        // IPv4 Header (20 bytes)
        packet[0] = 0x45.toByte() // Version 4, IHL 5 (20 bytes)
        packet[1] = 0x00.toByte() // DSCP/ECN
        packet[2] = ((totalLength shr 8) and 0xFF).toByte()
        packet[3] = (totalLength and 0xFF).toByte()

        val id = packetIdCounter.getAndIncrement()
        packet[4] = ((id shr 8) and 0xFF).toByte()
        packet[5] = (id and 0xFF).toByte()
        packet[6] = 0x40.toByte() // Don't fragment
        packet[7] = 0x00.toByte()
        packet[8] = 64.toByte()   // TTL
        packet[9] = 17.toByte()   // Protocol = UDP

        // Checksum at 10..11 initially 0
        System.arraycopy(srcIp, 0, packet, 12, 4)
        System.arraycopy(dstIp, 0, packet, 16, 4)

        val checksum = computeChecksum(packet, 0, 20)
        packet[10] = ((checksum shr 8) and 0xFF).toByte()
        packet[11] = (checksum and 0xFF).toByte()

        // UDP Header (8 bytes at offset 20)
        packet[20] = ((srcPort shr 8) and 0xFF).toByte()
        packet[21] = (srcPort and 0xFF).toByte()
        packet[22] = ((dstPort shr 8) and 0xFF).toByte()
        packet[23] = (dstPort and 0xFF).toByte()

        val udpLen = 8 + payload.size
        packet[24] = ((udpLen shr 8) and 0xFF).toByte()
        packet[25] = (udpLen and 0xFF).toByte()
        packet[26] = 0.toByte() // Checksum optional in IPv4 UDP
        packet[27] = 0.toByte()

        // Payload
        System.arraycopy(payload, 0, packet, 28, payload.size)
        return packet
    }

    private fun computeChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i < end) {
            val b1 = data[i].toInt() and 0xFF
            val b2 = data[i + 1].toInt() and 0xFF
            sum += (b1 shl 8) or b2
            i += 2
        }
        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun stopCapture() {
        captureJob?.cancel()
        captureJob = null
        try {
            forwardSocket?.close()
        } catch (_: Exception) {}
        forwardSocket = null
        try {
            vpnInterface?.close()
        } catch (_: Exception) { }
        vpnInterface = null
        PacketRepository.getInstance(applicationContext).setCapturing(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Packet Shark Active Capture",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors real-time network traffic and suspicious events with app internet protection"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val config = CaptureConfigManager.getInstance(this)
        val mode = config.currentMode.value

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Packet Shark: Active Capture")
            .setContentText("Internet Protected: YouTube, X & other apps operating normally (${mode.title})")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.example.START_CAPTURE"
        const val ACTION_STOP = "com.example.STOP_CAPTURE"
        private const val CHANNEL_ID = "packet_shark_channel"
        private const val NOTIFICATION_ID = 1001
    }
}

