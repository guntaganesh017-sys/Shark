package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.repository.PacketRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.nio.ByteBuffer

class PacketCaptureVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var captureJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        if (vpnInterface != null) return

        try {
            val builder = Builder()
                .setSession("PacketSharkCapture")
                .addAddress("10.1.1.2", 32)
                .addRoute("0.0.0.0", 0)
                .setMtu(1500)
                .setBlocking(false)

            vpnInterface = builder.establish()
            val repo = PacketRepository.getInstance(applicationContext)
            repo.setCapturing(true)

            val pfd = vpnInterface ?: return
            val inStream = FileInputStream(pfd.fileDescriptor)

            captureJob?.cancel()
            captureJob = serviceScope.launch {
                val buffer = ByteBuffer.allocate(32768)
                val channel = inStream.channel

                while (isActive) {
                    buffer.clear()
                    val bytesRead = try {
                        channel.read(buffer)
                    } catch (e: Exception) {
                        -1
                    }

                    if (bytesRead > 0) {
                        buffer.flip()
                        val packetData = ByteArray(bytesRead)
                        buffer.get(packetData)
                        repo.ingestRawPacket(packetData)
                    } else {
                        // Short sleep to prevent busy spinning when non-blocking has no packets
                        Thread.sleep(15)
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback to simulation mode if device restricts local loopback VPN
            PacketRepository.getInstance(applicationContext).startContinuousSimulation()
        }
    }

    private fun stopCapture() {
        captureJob?.cancel()
        captureJob = null
        try {
            vpnInterface?.close()
        } catch (e: Exception) { }
        vpnInterface = null
        PacketRepository.getInstance(applicationContext).setCapturing(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Packet Shark Active Capture",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors real-time network traffic and suspicious events"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Packet Shark: Active Capture")
            .setContentText("Analyzing network packets in real-time...")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.example.START_CAPTURE"
        const val ACTION_STOP = "com.example.STOP_CAPTURE"
        private const val CHANNEL_ID = "packet_shark_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
