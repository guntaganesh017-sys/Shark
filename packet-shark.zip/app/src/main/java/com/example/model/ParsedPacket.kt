package com.example.model

data class ParsedPacket(
    val id: Long = 0,
    val packetNumber: Long = 0,
    val timestampMs: Long = System.currentTimeMillis(),
    val sourceIp: String,
    val destinationIp: String,
    val sourcePort: Int = 0,
    val destinationPort: Int = 0,
    val protocol: ProtocolType,
    val totalLength: Int,
    val info: String,
    val isSuspicious: Boolean = false,
    val threatLevel: ThreatLevel = ThreatLevel.NONE,
    val threatTitle: String = "",
    val threatReason: String = "",
    val threatMitigation: String = "",
    // Deep inspection fields
    val ipVersion: Int = 4,
    val ttl: Int = 64,
    val ipHeaderLength: Int = 20,
    val flags: String = "",
    val tcpSeq: Long = 0,
    val tcpAck: Long = 0,
    val tcpFlags: String = "",
    val windowSize: Int = 0,
    val dnsQueryDomain: String? = null,
    val dnsQueryType: String? = null,
    val httpMethod: String? = null,
    val httpPath: String? = null,
    val httpHost: String? = null,
    val tlsSni: String? = null,
    val rawBytes: ByteArray = byteArrayOf(),
    val payloadHex: String = "",
    val payloadAscii: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as ParsedPacket
        return id == other.id && packetNumber == other.packetNumber
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + packetNumber.hashCode()
        return result
    }
}

data class ThreatAlert(
    val id: Long = 0,
    val packetNumber: Long,
    val timestampMs: Long = System.currentTimeMillis(),
    val threatType: String,
    val severity: ThreatLevel,
    val sourceEndpoint: String,
    val destEndpoint: String,
    val description: String,
    val technicalEvidence: String,
    val remediation: String
)
