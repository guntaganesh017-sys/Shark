package com.example.model

enum class CaptureMode(val title: String, val subtitle: String) {
    SAFE_INTERNET(
        "Safe Internet Sentinel",
        "Prevents internet disruption for all apps (YouTube, X, Grok, browsers) while capturing DNS and threat activity"
    ),
    APP_BYPASS(
        "App Bypass Protection",
        "Bypasses selected apps from the VPN tunnel so they use direct high-speed internet"
    ),
    TARGET_APPS(
        "Target App Inspection",
        "Routes only specific applications to the packet sniffer, leaving all other apps untouched"
    )
}

data class AppBypassItem(
    val packageName: String,
    val appName: String,
    val isBypassed: Boolean = true,
    val isTarget: Boolean = false
)
