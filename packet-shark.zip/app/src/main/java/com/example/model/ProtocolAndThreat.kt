package com.example.model

enum class ProtocolType(val displayName: String, val hexCode: Int) {
    TCP("TCP", 6),
    UDP("UDP", 17),
    ICMP("ICMP", 1),
    DNS("DNS", 53),
    HTTP("HTTP", 80),
    TLS("TLS", 443),
    OTHER("OTHER", 0);

    companion object {
        fun fromIpProtocol(proto: Int, srcPort: Int = 0, dstPort: Int = 0): ProtocolType {
            return when (proto) {
                1 -> ICMP
                6 -> {
                    when {
                        srcPort == 80 || dstPort == 80 || srcPort == 8080 || dstPort == 8080 -> HTTP
                        srcPort == 443 || dstPort == 443 || srcPort == 8443 || dstPort == 8443 -> TLS
                        else -> TCP
                    }
                }
                17 -> {
                    when {
                        srcPort == 53 || dstPort == 53 || srcPort == 5353 || dstPort == 5353 -> DNS
                        srcPort == 443 || dstPort == 443 -> TLS // QUIC / HTTP3
                        else -> UDP
                    }
                }
                else -> OTHER
            }
        }
    }
}

enum class ThreatLevel(val label: String, val weight: Int) {
    NONE("Safe", 0),
    LOW("Low", 1),
    MEDIUM("Medium", 2),
    HIGH("High", 3)
}
