package com.example.generator

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import kotlin.random.Random

object TrafficSimulationEngine {

    enum class Scenario(val title: String, val description: String) {
        NORMAL_WEB("Normal Web Traffic", "Standard HTTPS TLS 1.3 handshakes, DNS lookups, and API calls"),
        PASSWORD_LEAK("Credential Leak (Attack)", "Unencrypted HTTP POST transmitting plaintext passwords and API keys"),
        PORT_SCAN("TCP Port Scan (Recon)", "Sequential SYN scanning against ports 21, 22, 80, 443, 3306, 8080"),
        DNS_TUNNEL("DNS Exfiltration (Tunnel)", "Covert data exfiltration using large encoded DNS query subdomains"),
        METASPLOIT_C2("Metasploit Reverse Shell", "Suspicious TCP connection to port 4444 command and control"),
        ADB_EXPOSED("Android ADB Port Exposed", "Traffic to unauthenticated ADB port 5555 on local network")
    }

    fun generateScenarioPackets(scenario: Scenario, basePacketNum: Long): List<ByteArray> {
        return when (scenario) {
            Scenario.NORMAL_WEB -> generateNormalWebPackets()
            Scenario.PASSWORD_LEAK -> listOf(createHttpPasswordPacket())
            Scenario.PORT_SCAN -> generatePortScanPackets()
            Scenario.DNS_TUNNEL -> generateDnsExfiltrationPackets()
            Scenario.METASPLOIT_C2 -> listOf(createMetasploitPacket())
            Scenario.ADB_EXPOSED -> listOf(createAdbExposedPacket())
        }
    }

    fun generateRandomPacket(): ByteArray {
        val r = Random.nextInt(100)
        return when {
            r < 35 -> createTlsPacket("api.github.com")
            r < 65 -> createDnsPacket("www.google.com")
            r < 80 -> createHttpPacket()
            r < 90 -> createIcmpPacket()
            else -> createTlsPacket("cdn.cloudflare.net")
        }
    }

    private fun generateNormalWebPackets(): List<ByteArray> {
        return listOf(
            createDnsPacket("auth.mycompany.com"),
            createTlsPacket("auth.mycompany.com"),
            createDnsPacket("api.weather.org"),
            createTlsPacket("api.weather.org"),
            createIcmpPacket()
        )
    }

    private fun generatePortScanPackets(): List<ByteArray> {
        val targetIp = "192.168.1.105"
        val ports = listOf(21, 22, 23, 80, 443, 3306, 8080)
        return ports.map { port ->
            createTcpSynPacket(targetIp = targetIp, targetPort = port)
        }
    }

    private fun generateDnsExfiltrationPackets(): List<ByteArray> {
        val encodedPayload = "dGVzdC1jcmVkZW50aWFscy1leGZpbHRyYXRpb24tZGF0YS1wYXlsb2Fk"
        return listOf(
            createDnsPacket("$encodedPayload.tunnel.badactor.top", queryType = "TXT"),
            createDnsPacket("session4828194729104829104928104829.data.malicious-c2.xyz")
        )
    }

    // --- Packet Builder Helpers ---

    private fun buildIpHeader(
        protocol: Int,
        srcIpStr: String,
        dstIpStr: String,
        payloadSize: Int
    ): ByteArray {
        val totalLength = 20 + payloadSize
        val header = ByteArray(20)

        header[0] = 0x45.toByte() // IPv4, IHL = 5 (20 bytes)
        header[1] = 0x00.toByte() // DSCP / ECN
        header[2] = ((totalLength ushr 8) and 0xFF).toByte()
        header[3] = (totalLength and 0xFF).toByte()

        val id = Random.nextInt(65535)
        header[4] = ((id ushr 8) and 0xFF).toByte()
        header[5] = (id and 0xFF).toByte()

        header[6] = 0x40.toByte() // DF (Don't Fragment)
        header[7] = 0x00.toByte()

        header[8] = 64.toByte() // TTL
        header[9] = protocol.toByte() // 6=TCP, 17=UDP, 1=ICMP

        header[10] = 0.toByte() // Checksum placeholder
        header[11] = 0.toByte()

        val srcParts = srcIpStr.split(".").map { it.toInt() }
        for (i in 0..3) header[12 + i] = srcParts[i].toByte()

        val dstParts = dstIpStr.split(".").map { it.toInt() }
        for (i in 0..3) header[16 + i] = dstParts[i].toByte()

        return header
    }

    fun createDnsPacket(domain: String, queryType: String = "A"): ByteArray {
        val udpPayload = ByteArrayOutputStream()
        // Transaction ID
        udpPayload.write(byteArrayOf(0x1a.toByte(), 0x2b.toByte()))
        // Flags: Standard query (0x0100)
        udpPayload.write(byteArrayOf(0x01, 0x00))
        // Questions: 1
        udpPayload.write(byteArrayOf(0x00, 0x01))
        // Answers: 0, Authority: 0, Additional: 0
        udpPayload.write(byteArrayOf(0x00, 0x00, 0x00, 0x00, 0x00, 0x00))

        // Question Name labels
        for (label in domain.split(".")) {
            val bytes = label.toByteArray(StandardCharsets.US_ASCII)
            udpPayload.write(bytes.size)
            udpPayload.write(bytes)
        }
        udpPayload.write(0x00) // End of domain

        // Type (A = 1, TXT = 16)
        if (queryType == "TXT") {
            udpPayload.write(byteArrayOf(0x00, 0x10))
        } else {
            udpPayload.write(byteArrayOf(0x00, 0x01))
        }
        // Class IN (1)
        udpPayload.write(byteArrayOf(0x00, 0x01))

        val dnsData = udpPayload.toByteArray()

        // UDP Header (8 bytes)
        val udpHeader = ByteArray(8)
        val srcPort = 49152 + Random.nextInt(1000)
        val dstPort = 53
        val udpLen = 8 + dnsData.size

        udpHeader[0] = ((srcPort ushr 8) and 0xFF).toByte()
        udpHeader[1] = (srcPort and 0xFF).toByte()
        udpHeader[2] = ((dstPort ushr 8) and 0xFF).toByte()
        udpHeader[3] = (dstPort and 0xFF).toByte()
        udpHeader[4] = ((udpLen ushr 8) and 0xFF).toByte()
        udpHeader[5] = (udpLen and 0xFF).toByte()
        udpHeader[6] = 0 // Checksum
        udpHeader[7] = 0

        val ipHeader = buildIpHeader(17, "192.168.1.100", "8.8.8.8", 8 + dnsData.size)

        val full = ByteArrayOutputStream()
        full.write(ipHeader)
        full.write(udpHeader)
        full.write(dnsData)
        return full.toByteArray()
    }

    fun createTlsPacket(sni: String): ByteArray {
        val tlsPayload = ByteArrayOutputStream()
        // Content Type: Handshake (22 = 0x16)
        // Version: TLS 1.0 (3.1 = 0x03 0x01)
        // Length placeholder: 5 bytes
        val handshake = ByteArrayOutputStream()
        // Handshake type: Client Hello (1)
        handshake.write(0x01)
        // Handshake length placeholder
        val clientHello = ByteArrayOutputStream()
        // Client Version: TLS 1.2 (0x03 0x03)
        clientHello.write(byteArrayOf(0x03, 0x03))
        // Random (32 bytes)
        clientHello.write(ByteArray(32) { Random.nextInt(256).toByte() })
        // Session ID length: 0
        clientHello.write(0x00)
        // Cipher Suites length: 4
        clientHello.write(byteArrayOf(0x00, 0x04, 0x13.toByte(), 0x01, 0x13.toByte(), 0x02))
        // Compression methods: 1, 0
        clientHello.write(byteArrayOf(0x01, 0x00))

        // Extensions
        val extensions = ByteArrayOutputStream()
        // Extension: Server Name Indication (0x0000)
        val sniBytes = sni.toByteArray(StandardCharsets.US_ASCII)
        val sniExtData = ByteArrayOutputStream()
        val listLen = sniBytes.size + 3
        sniExtData.write(byteArrayOf(((listLen ushr 8) and 0xFF).toByte(), (listLen and 0xFF).toByte()))
        sniExtData.write(0x00) // Host Name type
        sniExtData.write(byteArrayOf(((sniBytes.size ushr 8) and 0xFF).toByte(), (sniBytes.size and 0xFF).toByte()))
        sniExtData.write(sniBytes)

        val extDataArr = sniExtData.toByteArray()
        extensions.write(byteArrayOf(0x00, 0x00))
        extensions.write(byteArrayOf(((extDataArr.size ushr 8) and 0xFF).toByte(), (extDataArr.size and 0xFF).toByte()))
        extensions.write(extDataArr)

        val extArr = extensions.toByteArray()
        clientHello.write(byteArrayOf(((extArr.size ushr 8) and 0xFF).toByte(), (extArr.size and 0xFF).toByte()))
        clientHello.write(extArr)

        val clientHelloArr = clientHello.toByteArray()
        val chLen = clientHelloArr.size
        handshake.write(byteArrayOf(((chLen ushr 16) and 0xFF).toByte(), ((chLen ushr 8) and 0xFF).toByte(), (chLen and 0xFF).toByte()))
        handshake.write(clientHelloArr)

        val handshakeArr = handshake.toByteArray()
        tlsPayload.write(0x16) // Handshake
        tlsPayload.write(byteArrayOf(0x03, 0x01)) // TLS 1.0 record
        tlsPayload.write(byteArrayOf(((handshakeArr.size ushr 8) and 0xFF).toByte(), (handshakeArr.size and 0xFF).toByte()))
        tlsPayload.write(handshakeArr)

        val appPayload = tlsPayload.toByteArray()
        return createTcpPacket(
            srcIp = "192.168.1.100",
            dstIp = "142.250.190.46",
            srcPort = 52418,
            dstPort = 443,
            flags = 0x18, // PSH, ACK
            payload = appPayload
        )
    }

    fun createHttpPasswordPacket(): ByteArray {
        val httpBody = "username=admin&password=SuperSecretPassword123!&token=ghp_920f381048201948291\r\n"
        val httpRequest = "POST /api/v1/auth/login HTTP/1.1\r\n" +
                "Host: insecure-api.corp.local\r\n" +
                "User-Agent: Mozilla/5.0 (Android; Mobile)\r\n" +
                "Content-Type: application/x-www-form-urlencoded\r\n" +
                "Content-Length: ${httpBody.length}\r\n\r\n" +
                httpBody

        return createTcpPacket(
            srcIp = "192.168.1.100",
            dstIp = "198.51.100.22",
            srcPort = 43920,
            dstPort = 80,
            flags = 0x18, // PSH, ACK
            payload = httpRequest.toByteArray(StandardCharsets.ISO_8859_1)
        )
    }

    private fun createHttpPacket(): ByteArray {
        val request = "GET /index.html HTTP/1.1\r\n" +
                "Host: example.com\r\n" +
                "User-Agent: AndroidClient/1.0\r\n" +
                "Accept: */*\r\n\r\n"
        return createTcpPacket(
            srcIp = "192.168.1.100",
            dstIp = "93.184.216.34",
            srcPort = 38924,
            dstPort = 80,
            flags = 0x18,
            payload = request.toByteArray(StandardCharsets.ISO_8859_1)
        )
    }

    private fun createMetasploitPacket(): ByteArray {
        val rawShellPayload = "id\nuname -a\nwhoami\n".toByteArray(StandardCharsets.US_ASCII)
        return createTcpPacket(
            srcIp = "192.168.1.100",
            dstIp = "203.0.113.88",
            srcPort = 51234,
            dstPort = 4444, // Metasploit default
            flags = 0x18,
            payload = rawShellPayload
        )
    }

    private fun createAdbExposedPacket(): ByteArray {
        val adbHandshake = "CNXN\u0000\u0000\u0000\u0001\u0000\u0010\u0000\u0000host::\u0000".toByteArray(StandardCharsets.US_ASCII)
        return createTcpPacket(
            srcIp = "192.168.1.18",
            dstIp = "192.168.1.100",
            srcPort = 41209,
            dstPort = 5555, // Android ADB network
            flags = 0x18,
            payload = adbHandshake
        )
    }

    private fun createTcpSynPacket(targetIp: String, targetPort: Int): ByteArray {
        return createTcpPacket(
            srcIp = "192.168.1.100",
            dstIp = targetIp,
            srcPort = 54000 + Random.nextInt(500),
            dstPort = targetPort,
            flags = 0x02, // SYN
            payload = byteArrayOf()
        )
    }

    private fun createIcmpPacket(): ByteArray {
        val icmpPayload = ByteArray(32) { 0x41.toByte() } // 'A'
        val icmp = ByteArray(8 + icmpPayload.size)
        icmp[0] = 8 // Echo Request
        icmp[1] = 0 // Code
        icmp[2] = 0 // Checksum
        icmp[3] = 0
        icmp[4] = 0x12 // Id
        icmp[5] = 0x34
        icmp[6] = 0x00 // Sequence
        icmp[7] = 0x01
        System.arraycopy(icmpPayload, 0, icmp, 8, icmpPayload.size)

        val ipHeader = buildIpHeader(1, "192.168.1.100", "8.8.4.4", icmp.size)
        val full = ByteArrayOutputStream()
        full.write(ipHeader)
        full.write(icmp)
        return full.toByteArray()
    }

    private fun createTcpPacket(
        srcIp: String,
        dstIp: String,
        srcPort: Int,
        dstPort: Int,
        flags: Int,
        payload: ByteArray
    ): ByteArray {
        val tcpHeader = ByteArray(20)
        tcpHeader[0] = ((srcPort ushr 8) and 0xFF).toByte()
        tcpHeader[1] = (srcPort and 0xFF).toByte()
        tcpHeader[2] = ((dstPort ushr 8) and 0xFF).toByte()
        tcpHeader[3] = (dstPort and 0xFF).toByte()

        val seq = Random.nextLong(4294967295L)
        tcpHeader[4] = ((seq ushr 24) and 0xFF).toByte()
        tcpHeader[5] = ((seq ushr 16) and 0xFF).toByte()
        tcpHeader[6] = ((seq ushr 8) and 0xFF).toByte()
        tcpHeader[7] = (seq and 0xFF).toByte()

        tcpHeader[8] = 0
        tcpHeader[9] = 0
        tcpHeader[10] = 0
        tcpHeader[11] = 0

        tcpHeader[12] = 0x50.toByte() // 5 * 4 = 20 bytes data offset
        tcpHeader[13] = flags.toByte()

        tcpHeader[14] = 0xFA.toByte() // Window 64000
        tcpHeader[15] = 0x00.toByte()

        tcpHeader[16] = 0 // Checksum
        tcpHeader[17] = 0
        tcpHeader[18] = 0 // Urgent ptr
        tcpHeader[19] = 0

        val ipHeader = buildIpHeader(6, srcIp, dstIp, 20 + payload.size)
        val full = ByteArrayOutputStream()
        full.write(ipHeader)
        full.write(tcpHeader)
        full.write(payload)
        return full.toByteArray()
    }
}
