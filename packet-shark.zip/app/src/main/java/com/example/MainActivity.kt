package com.example

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AttackScenarioDialog
import com.example.ui.components.CaptureRoutingConfigDialog
import com.example.ui.components.PacketDetailSheet
import com.example.ui.screens.LivePacketsScreen
import com.example.ui.screens.StatisticsScreen
import com.example.ui.screens.ThreatsScreen
import com.example.ui.theme.CyberAccent
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberError
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSuccess
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PacketMonitorViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PacketMonitorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: PacketMonitorViewModel) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    val isCapturing by viewModel.isCapturing.collectAsStateWithLifecycle()
    val threatAlerts by viewModel.threatAlerts.collectAsStateWithLifecycle()
    val selectedPacket by viewModel.selectedPacket.collectAsStateWithLifecycle()
    val showScenarioDialog by viewModel.showScenarioDialog.collectAsStateWithLifecycle()
    val showRoutingDialog by viewModel.showRoutingDialog.collectAsStateWithLifecycle()
    val captureMode by viewModel.captureMode.collectAsStateWithLifecycle()
    val bypassedPackages by viewModel.bypassedPackages.collectAsStateWithLifecycle()
    val targetPackages by viewModel.targetPackages.collectAsStateWithLifecycle()

    // Notification Permission Launcher (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Permission result handled gracefully */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // VPN Preparation Result Launcher
    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.startVpnService(context)
            Toast.makeText(context, "Network packet capture activated", Toast.LENGTH_SHORT).show()
        } else {
            // If user cancels VPN dialog, activate live traffic simulator so app works seamlessly
            viewModel.toggleSimulation()
            Toast.makeText(context, "Live Simulation Mode active", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                isCapturing = isCapturing,
                onToggleCapture = {
                    if (isCapturing) {
                        viewModel.stopCapture(context)
                        Toast.makeText(context, "Capture stopped", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.onStartCaptureClick(context) { vpnIntent ->
                            vpnLauncher.launch(vpnIntent)
                        }
                    }
                },
                onOpenScenarios = { viewModel.setShowScenarioDialog(true) },
                onOpenRoutingConfig = { viewModel.setShowRoutingDialog(true) }
            )
        },
        bottomBar = {
            BottomNavBar(
                selectedTab = selectedTab,
                onTabSelect = { selectedTab = it },
                threatCount = threatAlerts.size
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        modifier = Modifier.fillMaxSize()
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                0 -> LivePacketsScreen(
                    viewModel = viewModel,
                    onNavigateToThreats = { selectedTab = 1 }
                )
                1 -> ThreatsScreen(
                    viewModel = viewModel
                )
                2 -> StatisticsScreen(
                    viewModel = viewModel
                )
            }
        }

        // Selected Packet Detail Dissector Sheet
        selectedPacket?.let { packet ->
            PacketDetailSheet(
                packet = packet,
                onDismiss = { viewModel.selectPacket(null) }
            )
        }

        // Attack & Traffic Simulation Scenario Dialog
        if (showScenarioDialog) {
            AttackScenarioDialog(
                onDismiss = { viewModel.setShowScenarioDialog(false) },
                onSelectScenario = { scenario ->
                    viewModel.injectScenario(scenario)
                    Toast.makeText(context, "Injected ${scenario.title}", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Internet Protection & App Bypass Routing Dialog
        if (showRoutingDialog) {
            CaptureRoutingConfigDialog(
                currentMode = captureMode,
                bypassedPackages = bypassedPackages,
                targetPackages = targetPackages,
                installedApps = viewModel.getInstalledApps(),
                isCapturing = isCapturing,
                onSelectMode = { mode -> viewModel.setCaptureMode(mode, context) },
                onToggleBypass = { pkg, bypass -> viewModel.toggleBypass(pkg, bypass, context) },
                onToggleTarget = { pkg, target -> viewModel.toggleTarget(pkg, target, context) },
                onDismiss = { viewModel.setShowRoutingDialog(false) }
            )
        }
    }
}

@Composable
private fun TopAppBar(
    isCapturing: Boolean,
    onToggleCapture: () -> Unit,
    onOpenScenarios: () -> Unit,
    onOpenRoutingConfig: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .background(CyberSurface)
            .border(1.dp, CyberBorder)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Title & Logo
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberAccent.copy(alpha = 0.2f))
                        .border(1.dp, CyberAccent, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Packet Shark",
                        tint = CyberAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "PACKET SHARK",
                            color = CyberTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyberAccent.copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "v1.0",
                                color = CyberAccent,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "Real-Time Deep Network Analyzer",
                        color = CyberTextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            // Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Internet Protection & App Bypass Routing Settings
                IconButton(
                    onClick = onOpenRoutingConfig,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(CyberSurfaceElevated)
                        .border(1.dp, CyberSuccess.copy(alpha = 0.5f), CircleShape)
                        .testTag("top_routing_config_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Internet Protection & App Bypass",
                        tint = CyberSuccess,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Test Attack Scenarios Button
                IconButton(
                    onClick = onOpenScenarios,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(CyberSurfaceElevated)
                        .border(1.dp, CyberBorder, CircleShape)
                        .testTag("top_scenarios_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = "Simulate Traffic & Attacks",
                        tint = CyberWarning,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Start / Stop Capture Button
                Button(
                    onClick = onToggleCapture,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCapturing) CyberError else CyberSuccess
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("toggle_capture_button")
                ) {
                    Icon(
                        imageVector = if (isCapturing) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isCapturing) "STOP" else "START",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomNavBar(
    selectedTab: Int,
    onTabSelect: (Int) -> Unit,
    threatCount: Int
) {
    NavigationBar(
        containerColor = CyberSurface,
        tonalElevation = 8.dp,
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .border(1.dp, CyberBorder)
            .testTag("bottom_navigation_bar")
    ) {
        NavigationBarItem(
            selected = selectedTab == 0,
            onClick = { onTabSelect(0) },
            icon = {
                Icon(
                    imageVector = Icons.Default.List,
                    contentDescription = "Packets"
                )
            },
            label = { Text("Packets", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberAccent,
                selectedTextColor = CyberAccent,
                indicatorColor = CyberAccent.copy(alpha = 0.15f),
                unselectedIconColor = CyberTextMuted,
                unselectedTextColor = CyberTextMuted
            ),
            modifier = Modifier.testTag("nav_packets_tab")
        )

        NavigationBarItem(
            selected = selectedTab == 1,
            onClick = { onTabSelect(1) },
            icon = {
                if (threatCount > 0) {
                    BadgedBox(
                        badge = {
                            Badge(containerColor = CyberError) {
                                Text(
                                    text = threatCount.toString(),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Threats"
                        )
                    }
                } else {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Threats"
                    )
                }
            },
            label = { Text("Threats", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = if (threatCount > 0) CyberError else CyberAccent,
                selectedTextColor = if (threatCount > 0) CyberError else CyberAccent,
                indicatorColor = if (threatCount > 0) CyberError.copy(alpha = 0.15f) else CyberAccent.copy(alpha = 0.15f),
                unselectedIconColor = CyberTextMuted,
                unselectedTextColor = CyberTextMuted
            ),
            modifier = Modifier.testTag("nav_threats_tab")
        )

        NavigationBarItem(
            selected = selectedTab == 2,
            onClick = { onTabSelect(2) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Insights,
                    contentDescription = "Statistics"
                )
            },
            label = { Text("Statistics", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberAccent,
                selectedTextColor = CyberAccent,
                indicatorColor = CyberAccent.copy(alpha = 0.15f),
                unselectedIconColor = CyberTextMuted,
                unselectedTextColor = CyberTextMuted
            ),
            modifier = Modifier.testTag("nav_statistics_tab")
        )
    }
}
