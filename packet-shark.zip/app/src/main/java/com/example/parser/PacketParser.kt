package com.example.parser

import com.example.model.ParsedPacket
import com.example.model.ProtocolType
import java.nio.charset.StandardCharsets
import java.util.Locale

object PacketParser {

    fun parse(
        packetBytes: ByteArray,
        packetNumber: Long,
        timestampMs: Long = System.currentTimeMillis()
    ): ParsedPacket? {
        if (packetBytes.size < 20) return null

        try {
            val firstByte = packetBytes[0].toInt() and 0xFF
            val ipVersion = (firstByte ushr 4) and 0x0F

            if (ipVersion == 4) {
                return parseIPv4(packetBytes, packetNumber, timestampMs)
            } else if (ipVersion == 6) {
                return parseIPv6(packetBytes, packetNumber, timestampMs)
            }
        } catch (e: Exception) {
            // Fallback gracefully on corrupt packet
        }
        return null
    }

    private fun parseIPv4(
        packetBytes: ByteArray,
        packetNumber: Long,
        timestampMs: Long
    ): ParsedPacket {
        val firstByte = packetBytes[0].toInt() and 0xFF
        val ihl = (firstByte and 0x0F) * 4
        val totalLength = ((packetBytes[2].toInt() and 0xFF) shl 8) or (packetBytes[3].toInt() and 0xFF)
        val clampedLength = if (totalLength in 20..packetBytes.size) totalLength else packetBytes.size

        val flagsAndFrag = ((packetBytes[6].toInt() and 0xFF) shl 8) or (packetBytes[7].toInt() and 0xFF)
        val df = (flagsAndFrag and 0x4000) != 0
        val mf = (flagsAndFrag and 0x2000) != 0
        val flagStr = buildString {
            if (df) append("DF ")
            if (mf) append("MF ")
        }.trim()

        val ttl = packetBytes[8].toInt() and 0xFF
        val protocolNum = packetBytes[9].toInt() and 0xFF

        val srcIp = "${packetBytes[12].toInt() and 0xFF}.${packetBytes[13].toInt() and 0xFF}.${packetBytes[14].toInt() and 0xFF}.${packetBytes[15].toInt() and 0xFF}"
        val dstIp = "${packetBytes[16].toInt() and 0xFF}.${packetBytes[17].toInt() and 0xFF}.${packetBytes[18].toInt() and 0xFF}.${packetBytes[19].toInt() and 0xFF}"

        var srcPort = 0
        var dstPort = 0
        var tcpSeq = 0L
        var tcpAck = 0L
        var tcpFlags = ""
        var windowSize = 0
        var info = ""
        var dnsDomain: String? = null
        var dnsType: String? = null
        var httpMethod: String? = null
        var httpPath: String? = null
        var httpHost: String? = null
        var tlsSni: String? = null

        val transportOffset = ihl
        val payloadBytes: ByteArray

        when (protocolNum) {
            6 -> { // TCP
                if (packetBytes.size >= transportOffset + 20) {
                    srcPort = ((packetBytes[transportOffset].toInt() and 0xFF) shl 8) or (packetBytes[transportOffset + 1].toInt() and 0xFF)
                    dstPort = ((packetBytes[transportOffset + 2].toInt() and 0xFF) shl 8) or (packetBytes[transportOffset + 3].toInt() and 0xFF)

                    tcpSeq = readUint32(packetBytes, transportOffset + 4)
                    tcpAck = readUint32(packetBytes, transportOffset + 8)

                    val dataOffsetByte = packetBytes[transportOffset + 12].toInt() and 0xFF
                    val tcpHeaderLen = ((dataOffsetByte ushr 4) and 0x0F) * 4
                    val flagsByte = packetBytes[transportOffset + 13].toInt() and 0xFF

                    tcpFlags = formatTcpFlags(flagsByte)
                    windowSize = ((packetBytes[transportOffset + 14].toInt() and 0xFF) shl 8) or (packetBytes[transportOffset + 15].toInt() and 0xFF)

                    val appOffset = transportOffset + tcpHeaderLen
                    if (appOffset < clampedLength) {
                        payloadBytes = packetBytes.copyOfRange(appOffset, clampedLength)

                        // Check HTTP
                        val httpInfo = tryParseHttp(payloadBytes)
                        if (httpInfo != null) {
                            httpMethod = httpInfo.method
                            httpPath = httpInfo.path
                            httpHost = httpInfo.host
                            info = "HTTP ${httpInfo.summary}"
                        } else {
                            // Check TLS ClientHello
                            val sni = tryParseTlsSni(payloadBytes)
                            if (sni != null) {
                                tlsSni = sni
                                info = "TLS Client Hello [SNI: $sni]"
                            } else if (srcPort == 443 || dstPort == 443 || srcPort == 8443 || dstPort == 8443) {
                                info = "TLS Data len=${payloadBytes.size}"
                            } else {
                                info = "$srcPort → $dstPort [$tcpFlags] Seq=$tcpSeq Win=$windowSize Len=${payloadBytes.size}"
                            }
                        }
                    } else {
                        payloadBytes = byteArrayOf()
                        info = "$srcPort → $dstPort [$tcpFlags] Seq=$tcpSeq Ack=$tcpAck Win=$windowSize"
                    }
                } else {
                    payloadBytes = byteArrayOf()
                    info = "Truncated TCP packet"
                }
            }
            17 -> { // UDP
                if (packetBytes.size >= transportOffset + 8) {
                    srcPort = ((packetBytes[transportOffset].toInt() and 0xFF) shl 8) or (packetBytes[transportOffset + 1].toInt() and 0xFF)
                    dstPort = ((packetBytes[transportOffset + 2].toInt() and 0xFF) shl 8) or (packetBytes[transportOffset + 3].toInt() and 0xFF)
                    val udpLen = ((packetBytes[transportOffset + 4].toInt() and 0xFF) shl 8) or (packetBytes[transportOffset + 5].toInt() and 0xFF)

                    val appOffset = transportOffset + 8
                    if (appOffset < clampedLength) {
                        payloadBytes = packetBytes.copyOfRange(appOffset, clampedLength)
                        if (srcPort == 53 || dstPort == 53 || srcPort == 5353 || dstPort == 5353) {
                            val dns = tryParseDns(payloadBytes)
                            if (dns != null) {
                                dnsDomain = dns.domain
                                dnsType = dns.queryType
                                info = "DNS ${if (dns.isResponse) "Standard query response" else "Standard query"} 0x${dns.txId.toString(16)} ${dns.queryType} ${dns.domain}"
                            } else {
                                info = "DNS len=${payloadBytes.size}"
                            }
                        } else {
                            info = "$srcPort → $dstPort Len=$udpLen"
                        }
                    } else {
                        payloadBytes = byteArrayOf()
                        info = "$srcPort → $dstPort Len=$udpLen"
                    }
                } else {
                    payloadBytes = byteArrayOf()
                    info = "Truncated UDP packet"
                }
            }
            1 -> { // ICMP
                payloadBytes = if (transportOffset < clampedLength) {
                    packetBytes.copyOfRange(transportOffset, clampedLength)
                } else byteArrayOf()

                val icmpType = if (payloadBytes.isNotEmpty()) payloadBytes[0].toInt() and 0xFF else 0
                val icmpCode = if (payloadBytes.size > 1) payloadBytes[1].toInt() and 0xFF else 0
                val icmpName = when (icmpType) {
                    0 -> "Echo (ping) reply"
                    3 -> "Destination unreachable (Code: $icmpCode)"
                    8 -> "Echo (ping) request"
                    11 -> "Time-to-live exceeded"
                    else -> "Type: $icmpType Code: $icmpCode"
                }
                info = "ICMP $icmpName"
            }
            else -> {
                payloadBytes = if (transportOffset < clampedLength) {
                    packetBytes.copyOfRange(transportOffset, clampedLength)
                } else byteArrayOf()
                info = "IPv4 Protocol $protocolNum Len=$clampedLength"
            }
        }

        val protocol = ProtocolType.fromIpProtocol(protocolNum, srcPort, dstPort)
        val finalProtocol = if (httpMethod != null) ProtocolType.HTTP
            else if (tlsSni != null || (protocol == ProtocolType.TCP && (srcPort == 443 || dstPort == 443))) ProtocolType.TLS
            else if (dnsDomain != null || srcPort == 53 || dstPort == 53) ProtocolType.DNS
            else protocol

        val hexDump = formatHexDump(packetBytes.copyOfRange(0, clampedLength))
        val asciiDump = formatAsciiDump(packetBytes.copyOfRange(0, clampedLength))

        return ParsedPacket(
            packetNumber = packetNumber,
            timestampMs = timestampMs,
            sourceIp = srcIp,
            destinationIp = dstIp,
            sourcePort = srcPort,
            destinationPort = dstPort,
            protocol = finalProtocol,
            totalLength = clampedLength,
            info = info,
            ipVersion = 4,
            ttl = ttl,
            ipHeaderLength = ihl,
            flags = flagStr,
            tcpSeq = tcpSeq,
            tcpAck = tcpAck,
            tcpFlags = tcpFlags,
            windowSize = windowSize,
            dnsQueryDomain = dnsDomain,
            dnsQueryType = dnsType,
            httpMethod = httpMethod,
            httpPath = httpPath,
            httpHost = httpHost,
            tlsSni = tlsSni,
            rawBytes = packetBytes.copyOfRange(0, clampedLength),
            payloadHex = hexDump,
            payloadAscii = asciiDump
        )
    }

    private fun parseIPv6(
        packetBytes: ByteArray,
        packetNumber: Long,
        timestampMs: Long
    ): ParsedPacket {
        val payloadLen = ((packetBytes[4].toInt() and 0xFF) shl 8) or (packetBytes[5].toInt() and 0xFF)
        val nextHeader = packetBytes[6].toInt() and 0xFF
        val hopLimit = packetBytes[7].toInt() and 0xFF

        val srcIp = formatIPv6(packetBytes, 8)
        val dstIp = formatIPv6(packetBytes, 24)

        val totalLen = (40 + payloadLen).coerceAtMost(packetBytes.size)
        val hexDump = formatHexDump(packetBytes.copyOfRange(0, totalLen))
        val asciiDump = formatAsciiDump(packetBytes.copyOfRange(0, totalLen))

        return ParsedPacket(
            packetNumber = packetNumber,
            timestampMs = timestampMs,
            sourceIp = srcIp,
            destinationIp = dstIp,
            sourcePort = 0,
            destinationPort = 0,
            protocol = ProtocolType.fromIpProtocol(nextHeader),
            totalLength = totalLen,
            info = "IPv6 NextHeader=$nextHeader HopLimit=$hopLimit",
            ipVersion = 6,
            ttl = hopLimit,
            ipHeaderLength = 40,
            rawBytes = packetBytes.copyOfRange(0, totalLen),
            payloadHex = hexDump,
            payloadAscii = asciiDump
        )
    }

    private fun formatIPv6(bytes: ByteArray, offset: Int): String {
        return buildString {
            for (i in 0 until 8) {
                val value = ((bytes[offset + i * 2].toInt() and 0xFF) shl 8) or (bytes[offset + i * 2 + 1].toInt() and 0xFF)
                if (i > 0) append(":")
                append(value.toString(16))
            }
        }
    }

    private fun readUint32(bytes: ByteArray, offset: Int): Long {
        return ((bytes[offset].toLong() and 0xFF) shl 24) or
               ((bytes[offset + 1].toLong() and 0xFF) shl 16) or
               ((bytes[offset + 2].toLong() and 0xFF) shl 8) or
               (bytes[offset + 3].toLong() and 0xFF)
    }

    private fun formatTcpFlags(flagsByte: Int): String {
        val parts = mutableListOf<String>()
        if ((flagsByte and 0x20) != 0) parts.add("URG")
        if ((flagsByte and 0x10) != 0) parts.add("ACK")
        if ((flagsByte and 0x08) != 0) parts.add("PSH")
        if ((flagsByte and 0x04) != 0) parts.add("RST")
        if ((flagsByte and 0x02) != 0) parts.add("SYN")
        if ((flagsByte and 0x01) != 0) parts.add("FIN")
        return parts.joinToString(",")
    }

    data class HttpInfo(val method: String, val path: String, val host: String?, val summary: String)

    private fun tryParseHttp(payload: ByteArray): HttpInfo? {
        if (payload.size < 4) return null
        val text = String(payload.copyOfRange(0, payload.size.coerceAtMost(512)), StandardCharsets.ISO_8859_1)
        val firstLine = text.substringBefore("\r\n").substringBefore("\n")

        val methods = listOf("GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS", "PATCH", "CONNECT")
        val matchMethod = methods.firstOrNull { firstLine.startsWith("$it ") }
        if (matchMethod != null) {
            val tokens = firstLine.split(" ")
            val path = if (tokens.size > 1) tokens[1] else "/"
            var host: String? = null
            for (line in text.lines()) {
                if (line.startsWith("Host:", ignoreCase = true)) {
                    host = line.substringAfter(":").trim()
                    break
                }
            }
            return HttpInfo(
                method = matchMethod,
                path = path,
                host = host,
                summary = "$matchMethod $path${if (host != null) " [$host]" else ""}"
            )
        }

        if (firstLine.startsWith("HTTP/1.") || firstLine.startsWith("HTTP/2")) {
            return HttpInfo(
                method = "RESP",
                path = "",
                host = null,
                summary = firstLine
            )
        }
        return null
    }

    data class DnsInfo(val txId: Int, val isResponse: Boolean, val domain: String, val queryType: String)

    private fun tryParseDns(payload: ByteArray): DnsInfo? {
        if (payload.size < 12) return null
        val txId = ((payload[0].toInt() and 0xFF) shl 8) or (payload[1].toInt() and 0xFF)
        val flags = ((payload[2].toInt() and 0xFF) shl 8) or (payload[3].toInt() and 0xFF)
        val isResponse = (flags and 0x8000) != 0
        val qdCount = ((payload[4].toInt() and 0xFF) shl 8) or (payload[5].toInt() and 0xFF)

        if (qdCount < 1) return null

        var offset = 12
        val labels = mutableListOf<String>()
        var jumped = false
        var count = 0

        while (offset < payload.size && count < 20) {
            val len = payload[offset].toInt() and 0xFF
            if (len == 0) {
                offset++
                break
            }
            if ((len and 0xC0) == 0xC0) {
                // Pointer compression
                offset += 2
                break
            }
            offset++
            if (offset + len <= payload.size) {
                labels.add(String(payload, offset, len, StandardCharsets.US_ASCII))
                offset += len
            } else {
                break
            }
            count++
        }

        val domain = if (labels.isNotEmpty()) labels.joinToString(".") else "unknown"
        var qTypeStr = "A"
        if (offset + 2 <= payload.size) {
            val qType = ((payload[offset].toInt() and 0xFF) shl 8) or (payload[offset + 1].toInt() and 0xFF)
            qTypeStr = when (qType) {
                1 -> "A"
                28 -> "AAAA"
                15 -> "MX"
                16 -> "TXT"
                5 -> "CNAME"
                12 -> "PTR"
                else -> "TYPE$qType"
            }
        }

        return DnsInfo(txId, isResponse, domain, qTypeStr)
    }

    private fun tryParseTlsSni(payload: ByteArray): String? {
        // Minimum TLS Record (5 bytes) + Handshake Header (4 bytes) + Client Hello
        if (payload.size < 43) return null
        // 0x16 = Handshake, 0x03 = TLS version major
        if (payload[0] != 0x16.toByte()) return null

        // Handshake type: 1 = Client Hello
        val handshakeType = payload[5].toInt() and 0xFF
        if (handshakeType != 1) return null

        var offset = 43 // Skip Record Header (5) + Handshake Header (4) + Client Version (2) + Random (32)
        if (offset >= payload.size) return null

        // Session ID length
        val sessionIdLen = payload[offset].toInt() and 0xFF
        offset += 1 + sessionIdLen
        if (offset + 2 > payload.size) return null

        // Cipher Suites length
        val cipherSuitesLen = ((payload[offset].toInt() and 0xFF) shl 8) or (payload[offset + 1].toInt() and 0xFF)
        offset += 2 + cipherSuitesLen
        if (offset + 1 > payload.size) return null

        // Compression methods length
        val compMethodsLen = payload[offset].toInt() and 0xFF
        offset += 1 + compMethodsLen
        if (offset + 2 > payload.size) return null

        // Extensions length
        val extensionsLen = ((payload[offset].toInt() and 0xFF) shl 8) or (payload[offset + 1].toInt() and 0xFF)
        offset += 2
        val extensionsEnd = (offset + extensionsLen).coerceAtMost(payload.size)

        while (offset + 4 <= extensionsEnd) {
            val extType = ((payload[offset].toInt() and 0xFF) shl 8) or (payload[offset + 1].toInt() and 0xFF)
            val extLen = ((payload[offset + 2].toInt() and 0xFF) shl 8) or (payload[offset + 3].toInt() and 0xFF)
            offset += 4

            if (extType == 0) { // Server Name Indication (SNI)
                if (offset + 2 <= extensionsEnd) {
                    val serverNameListLen = ((payload[offset].toInt() and 0xFF) shl 8) or (payload[offset + 1].toInt() and 0xFF)
                    var nameOffset = offset + 2
                    if (nameOffset + 3 <= extensionsEnd) {
                        val nameType = payload[nameOffset].toInt() and 0xFF
                        val nameLen = ((payload[nameOffset + 1].toInt() and 0xFF) shl 8) or (payload[nameOffset + 2].toInt() and 0xFF)
                        nameOffset += 3
                        if (nameType == 0 && nameOffset + nameLen <= extensionsEnd) {
                            return String(payload, nameOffset, nameLen, StandardCharsets.US_ASCII)
                        }
                    }
                }
            }
            offset += extLen
        }
        return null
    }

    fun formatHexDump(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (i in bytes.indices step 16) {
            sb.append(String.format(Locale.US, "%04x  ", i))
            val lineBytes = (bytes.size - i).coerceAtMost(16)
            for (j in 0 until 16) {
                if (j < lineBytes) {
                    sb.append(String.format(Locale.US, "%02x ", bytes[i + j]))
                } else {
                    sb.append("   ")
                }
                if (j == 7) sb.append(" ")
            }
            sb.append("\n")
        }
        return sb.toString().trimEnd()
    }

    fun formatAsciiDump(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (i in bytes.indices step 16) {
            val lineBytes = (bytes.size - i).coerceAtMost(16)
            for (j in 0 until lineBytes) {
                val b = bytes[i + j].toInt() and 0xFF
                if (b in 32..126) {
                    sb.append(b.toChar())
                } else {
                    sb.append('.')
                }
            }
            sb.append("\n")
        }
        return sb.toString().trimEnd()
    }
}
