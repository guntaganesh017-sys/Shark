package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.example.model.AppBypassItem
import com.example.model.CaptureMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CaptureConfigManager private constructor(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _currentMode = MutableStateFlow(loadMode())
    val currentMode: StateFlow<CaptureMode> = _currentMode.asStateFlow()

    private val _bypassedPackages = MutableStateFlow(loadBypassedPackages())
    val bypassedPackages: StateFlow<Set<String>> = _bypassedPackages.asStateFlow()

    private val _targetPackages = MutableStateFlow(loadTargetPackages())
    val targetPackages: StateFlow<Set<String>> = _targetPackages.asStateFlow()

    private fun loadMode(): CaptureMode {
        val name = prefs.getString(KEY_MODE, CaptureMode.SAFE_INTERNET.name) ?: CaptureMode.SAFE_INTERNET.name
        return try {
            CaptureMode.valueOf(name)
        } catch (_: Exception) {
            CaptureMode.SAFE_INTERNET
        }
    }

    private fun loadBypassedPackages(): Set<String> {
        val saved = prefs.getStringSet(KEY_BYPASSED, null)
        return saved ?: DEFAULT_BYPASSED_APPS
    }

    private fun loadTargetPackages(): Set<String> {
        val saved = prefs.getStringSet(KEY_TARGETS, null)
        return saved ?: emptySet()
    }

    fun setMode(mode: CaptureMode) {
        prefs.edit().putString(KEY_MODE, mode.name).apply()
        _currentMode.value = mode
    }

    fun setPackageBypassed(packageName: String, bypassed: Boolean) {
        val current = _bypassedPackages.value.toMutableSet()
        if (bypassed) {
            current.add(packageName)
        } else {
            current.remove(packageName)
        }
        prefs.edit().putStringSet(KEY_BYPASSED, current).apply()
        _bypassedPackages.value = current
    }

    fun setPackageTarget(packageName: String, isTarget: Boolean) {
        val current = _targetPackages.value.toMutableSet()
        if (isTarget) {
            current.add(packageName)
        } else {
            current.remove(packageName)
        }
        prefs.edit().putStringSet(KEY_TARGETS, current).apply()
        _targetPackages.value = current
    }

    fun getInstalledAppList(): List<AppBypassItem> {
        val pm = context.packageManager
        val bypassed = _bypassedPackages.value
        val targets = _targetPackages.value

        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = pm.queryIntentActivities(intent, 0)

        val seen = mutableSetOf<String>()
        val result = mutableListOf<AppBypassItem>()

        // First include popular apps even if not currently resolved by launcher
        for (pkg in KNOWN_POPULAR_APPS) {
            if (pkg == context.packageName) continue
            val appName = try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (_: Exception) {
                friendlyNameForPackage(pkg)
            }
            seen.add(pkg)
            result.add(
                AppBypassItem(
                    packageName = pkg,
                    appName = appName,
                    isBypassed = bypassed.contains(pkg),
                    isTarget = targets.contains(pkg)
                )
            )
        }

        // Then add other discovered launcher activities
        for (info in resolveInfos) {
            val pkg = info.activityInfo.packageName
            if (pkg == context.packageName || seen.contains(pkg)) continue
            seen.add(pkg)
            val name = info.loadLabel(pm).toString()
            result.add(
                AppBypassItem(
                    packageName = pkg,
                    appName = name,
                    isBypassed = bypassed.contains(pkg),
                    isTarget = targets.contains(pkg)
                )
            )
        }

        return result.sortedWith(
            compareByDescending<AppBypassItem> { it.isBypassed }
                .thenBy { it.appName.lowercase() }
        )
    }

    companion object {
        private const val PREFS_NAME = "packet_shark_capture_prefs"
        private const val KEY_MODE = "key_capture_mode"
        private const val KEY_BYPASSED = "key_bypassed_packages"
        private const val KEY_TARGETS = "key_target_packages"

        val KNOWN_POPULAR_APPS = listOf(
            "com.google.android.youtube",
            "com.twitter.android",
            "com.twitter.android.lite",
            "ai.x.grok",
            "com.android.chrome",
            "org.mozilla.firefox",
            "com.whatsapp",
            "com.instagram.android",
            "com.google.android.gm",
            "com.spotify.music",
            "com.netflix.mediaclient"
        )

        val DEFAULT_BYPASSED_APPS = setOf(
            "com.google.android.youtube",
            "com.twitter.android",
            "com.twitter.android.lite",
            "ai.x.grok",
            "com.android.chrome",
            "org.mozilla.firefox",
            "com.whatsapp",
            "com.instagram.android",
            "com.google.android.gm",
            "com.spotify.music",
            "com.netflix.mediaclient"
        )

        fun friendlyNameForPackage(pkg: String): String {
            return when (pkg) {
                "com.google.android.youtube" -> "YouTube"
                "com.twitter.android", "com.twitter.android.lite" -> "X (Twitter)"
                "ai.x.grok" -> "Grok"
                "com.android.chrome" -> "Google Chrome"
                "org.mozilla.firefox" -> "Firefox"
                "com.whatsapp" -> "WhatsApp"
                "com.instagram.android" -> "Instagram"
                "com.google.android.gm" -> "Gmail"
                "com.spotify.music" -> "Spotify"
                "com.netflix.mediaclient" -> "Netflix"
                else -> pkg.substringAfterLast('.')
            }
        }

        @Volatile
        private var INSTANCE: CaptureConfigManager? = null

        fun getInstance(context: Context): CaptureConfigManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CaptureConfigManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
