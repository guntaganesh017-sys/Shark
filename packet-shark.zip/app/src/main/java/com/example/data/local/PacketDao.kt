package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PacketDao {
    @Query("SELECT * FROM captured_packets ORDER BY packetNumber DESC LIMIT 500")
    fun getRecentPackets(): Flow<List<CapturedPacketEntity>>

    @Query("SELECT * FROM captured_packets WHERE isSuspicious = 1 ORDER BY packetNumber DESC")
    fun getSuspiciousPackets(): Flow<List<CapturedPacketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPacket(packet: CapturedPacketEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackets(packets: List<CapturedPacketEntity>)

    @Query("SELECT COUNT(*) FROM captured_packets")
    suspend fun getTotalCount(): Long

    @Query("SELECT COUNT(*) FROM captured_packets WHERE isSuspicious = 1")
    suspend fun getSuspiciousCount(): Long

    @Query("DELETE FROM captured_packets")
    suspend fun clearAll()
}
