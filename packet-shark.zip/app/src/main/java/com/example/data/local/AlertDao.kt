package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AlertDao {
    @Query("SELECT * FROM security_alerts ORDER BY timestampMs DESC LIMIT 200")
    fun getAllAlerts(): Flow<List<SecurityAlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: SecurityAlertEntity): Long

    @Query("SELECT COUNT(*) FROM security_alerts")
    suspend fun getAlertCount(): Long

    @Query("DELETE FROM security_alerts")
    suspend fun clearAll()
}
