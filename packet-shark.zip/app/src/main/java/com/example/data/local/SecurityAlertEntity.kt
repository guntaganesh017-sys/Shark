package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ThreatAlert
import com.example.model.ThreatLevel

@Entity(tableName = "security_alerts")
data class SecurityAlertEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packetNumber: Long,
    val timestampMs: Long,
    val threatType: String,
    val severity: String,
    val sourceEndpoint: String,
    val destEndpoint: String,
    val description: String,
    val technicalEvidence: String,
    val remediation: String
) {
    fun toThreatAlert(): ThreatAlert {
        val lvl = try {
            ThreatLevel.valueOf(severity)
        } catch (e: Exception) {
            ThreatLevel.MEDIUM
        }
        return ThreatAlert(
            id = id,
            packetNumber = packetNumber,
            timestampMs = timestampMs,
            threatType = threatType,
            severity = lvl,
            sourceEndpoint = sourceEndpoint,
            destEndpoint = destEndpoint,
            description = description,
            technicalEvidence = technicalEvidence,
            remediation = remediation
        )
    }

    companion object {
        fun fromThreatAlert(alert: ThreatAlert): SecurityAlertEntity {
            return SecurityAlertEntity(
                id = 0,
                packetNumber = alert.packetNumber,
                timestampMs = alert.timestampMs,
                threatType = alert.threatType,
                severity = alert.severity.name,
                sourceEndpoint = alert.sourceEndpoint,
                destEndpoint = alert.destEndpoint,
                description = alert.description,
                technicalEvidence = alert.technicalEvidence,
                remediation = alert.remediation
            )
        }
    }
}
