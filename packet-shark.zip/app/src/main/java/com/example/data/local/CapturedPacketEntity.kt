package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ParsedPacket
import com.example.model.ProtocolType
import com.example.model.ThreatLevel

@Entity(tableName = "captured_packets")
data class CapturedPacketEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packetNumber: Long,
    val timestampMs: Long,
    val sourceIp: String,
    val destinationIp: String,
    val sourcePort: Int,
    val destinationPort: Int,
    val protocol: String,
    val totalLength: Int,
    val info: String,
    val isSuspicious: Boolean,
    val threatLevel: String,
    val threatTitle: String,
    val threatReason: String,
    val threatMitigation: String,
    val ipVersion: Int,
    val ttl: Int,
    val ipHeaderLength: Int,
    val flags: String,
    val tcpSeq: Long,
    val tcpAck: Long,
    val tcpFlags: String,
    val windowSize: Int,
    val dnsQueryDomain: String?,
    val dnsQueryType: String?,
    val httpMethod: String?,
    val httpPath: String?,
    val httpHost: String?,
    val tlsSni: String?,
    val payloadHex: String,
    val payloadAscii: String
) {
    fun toParsedPacket(): ParsedPacket {
        val proto = try {
            ProtocolType.valueOf(protocol)
        } catch (e: Exception) {
            ProtocolType.OTHER
        }
        val tLevel = try {
            ThreatLevel.valueOf(threatLevel)
        } catch (e: Exception) {
            ThreatLevel.NONE
        }

        return ParsedPacket(
            id = id,
            packetNumber = packetNumber,
            timestampMs = timestampMs,
            sourceIp = sourceIp,
            destinationIp = destinationIp,
            sourcePort = sourcePort,
            destinationPort = destinationPort,
            protocol = proto,
            totalLength = totalLength,
            info = info,
            isSuspicious = isSuspicious,
            threatLevel = tLevel,
            threatTitle = threatTitle,
            threatReason = threatReason,
            threatMitigation = threatMitigation,
            ipVersion = ipVersion,
            ttl = ttl,
            ipHeaderLength = ipHeaderLength,
            flags = flags,
            tcpSeq = tcpSeq,
            tcpAck = tcpAck,
            tcpFlags = tcpFlags,
            windowSize = windowSize,
            dnsQueryDomain = dnsQueryDomain,
            dnsQueryType = dnsQueryType,
            httpMethod = httpMethod,
            httpPath = httpPath,
            httpHost = httpHost,
            tlsSni = tlsSni,
            payloadHex = payloadHex,
            payloadAscii = payloadAscii
        )
    }

    companion object {
        fun fromParsedPacket(packet: ParsedPacket): CapturedPacketEntity {
            return CapturedPacketEntity(
                id = 0, // Auto-generate
                packetNumber = packet.packetNumber,
                timestampMs = packet.timestampMs,
                sourceIp = packet.sourceIp,
                destinationIp = packet.destinationIp,
                sourcePort = packet.sourcePort,
                destinationPort = packet.destinationPort,
                protocol = packet.protocol.name,
                totalLength = packet.totalLength,
                info = packet.info,
                isSuspicious = packet.isSuspicious,
                threatLevel = packet.threatLevel.name,
                threatTitle = packet.threatTitle,
                threatReason = packet.threatReason,
                threatMitigation = packet.threatMitigation,
                ipVersion = packet.ipVersion,
                ttl = packet.ttl,
                ipHeaderLength = packet.ipHeaderLength,
                flags = packet.flags,
                tcpSeq = packet.tcpSeq,
                tcpAck = packet.tcpAck,
                tcpFlags = packet.tcpFlags,
                windowSize = packet.windowSize,
                dnsQueryDomain = packet.dnsQueryDomain,
                dnsQueryType = packet.dnsQueryType,
                httpMethod = packet.httpMethod,
                httpPath = packet.httpPath,
                httpHost = packet.httpHost,
                tlsSni = packet.tlsSni,
                payloadHex = packet.payloadHex,
                payloadAscii = packet.payloadAscii
            )
        }
    }
}
