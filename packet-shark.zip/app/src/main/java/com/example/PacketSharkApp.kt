package com.example

import android.app.Application
import com.example.repository.PacketRepository

class PacketSharkApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Pre-initialize repository
        PacketRepository.getInstance(this)
    }
}
